/**
 * server/server.js (v4) — Servidor AUTORITATIVO do TI Company Simulator
 */
'use strict';

const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const S = require('../shared/shared.js');

const PORT = process.env.PORT || 3000;
const app = express();
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/shared', express.static(path.join(__dirname, '..', 'shared')));
const server = http.createServer(app);
const io = new Server(server, { pingInterval: 10000, pingTimeout: 8000 });

// ============================================================================
// 1) CONFIGURAÇÃO E DADOS DE CONTEÚDO
// ============================================================================
const CFG = {
  FIRST_CLIENT: 3000,
  CLIENT_EVERY: 35000,
  MAX_WAIT: 5,
  SCAN_MS: 4000,
  PEN_MISTAKE: 5, PEN_MISROUTE: 10, SCORE_PER_STAR: 30,
};
const EMOTES = ['👍', '😅', '🔥', '🆘', '☕'];
const NAMES = [
  'Marta', 'Sr. Duarte', 'Inês', 'Rui', 'Dona Alice', 'Tiago', 'Beatriz', 'Prof. Lima',
  'Joana', 'Carlos', 'Helena', 'Vítor', 'Mariana', 'Sr. Costa', 'Lucas', 'Camila',
  'Dona Lurdes', 'Pedro', 'Sílvia', 'Fernando', 'Raquel', 'Henrique', 'Patrícia', 'André',
  'Cristina', 'Roberto', 'Daniela', 'Gustavo', 'Larissa', 'Felipe', 'Érica', 'Rodrigo',
  'Natália', 'Samuel', 'Juliana', 'Marcos', 'Letícia', 'Eduardo', 'Vanessa', 'Renato',
  'Priscila', 'Diego', 'Amanda', 'Bruno', 'Isabela', 'Rafael', 'Alessandra', 'Leandro',
];
const THANKS = [
  'Ainda tenho dúvidas se vão resolver... mas ok.',
  'Resolveram, mas demorou mais do que eu esperava.',
  'Tudo funcionando. Obrigado!',
  'Ficou ótimo, muito obrigado pela atenção!',
  'Atendimento impecável! Voltarei sempre!',
];

const PROBLEMS = {
  screen: {
    dept: 'hardware',
    intros: [
      'Deixei o PC cair e a tela rachou.',
      'Meu notebook caiu da mesa e agora a tela está toda riscada, com uma mancha preta no canto.',
      'Sentei em cima da mochila sem querer e a tela ficou toda trincada.',
      'Fui fechar a tela com uma caneta no teclado e quebrou tudo.',
      'O meu filho tropeçou no fio e o computador foi ao chão. A imagem está horrível.',
      'A tela está cheia de linhas coloridas e não consigo ver nada depois de uma pancada.',
      'Minha gata pulou no notebook e agora a tela tem uma rachadura enorme.',
      'Bateu na borda da mesa ao cair e ficou um grande borrão preto na tela.',
      'A tela não liga mais; ouço o Windows iniciando mas não aparece nada.',
      'Empurrei o notebook sem querer e caiu no chão de cimento. A tela está arrebentada.',
    ],
    clues: (p) => ({
      when: 'Foi hoje de manhã. O notebook escorregou da mesa e caiu no chão.',
      power: 'Liga normal, a luzinha acende e dá pra ouvir o ventilador, mas a imagem está toda quebrada.',
      restart: 'Reiniciei duas vezes e continua igual.',
      accident: 'Sim! Ele levou uma pancada forte.',
      devices: 'Quando ligo na TV da sala a imagem aparece certinha.',
      popups: 'Não aparece nada estranho, só a tela riscada mesmo.',
      files: 'Meus arquivos estão todos aí, pelo que consegui ver.',
      model: `É um notebook de ${p.model} polegadas.`,
    }),
  },
  ram: {
    dept: 'hardware',
    intros: [
      'O computador trava toda vez que abro mais de dois programas.',
      'O PC fica lento e às vezes aparece uma tela azul do nada.',
      'Desde que instalei um jogo novo, o computador fica travando sem parar.',
      'O sistema fica lento demais. Mal consigo usar o Word sem ele engasgar.',
      'O notebook aquece muito e começa a travar depois de uns 10 minutos de uso.',
      'Fica aparecendo mensagem de "memória insuficiente" e o PC desliga sozinho.',
    ],
    clues: (p) => ({
      when: 'Faz uns três meses que está assim, e foi piorando aos poucos.',
      power: 'Liga normalmente, mas demora muito pra carregar o sistema.',
      restart: 'Depois de reiniciar melhora um pouco, mas logo trava de novo.',
      accident: 'Não, nunca caiu. Só o uso normal mesmo.',
      devices: 'O celular e o tablet funcionam normal.',
      popups: 'Aparece uma tela azul de vez em quando com um código de erro.',
      files: 'Os arquivos estão todos lá, não perdi nada.',
      model: `É um notebook de ${p.model} polegadas.`,
    }),
  },
  storage: {
    dept: 'hardware',
    intros: [
      'O computador está muito lento para abrir qualquer arquivo.',
      'Leva quase dez minutos para o Windows carregar completamente.',
      'O HD faz um barulho esquisito de click, click, click quando ligo.',
      'Meus arquivos sumiram depois que o PC travou e eu tive que forçar o desligamento.',
      'O sistema avisa que o disco está com problemas e precisa ser verificado.',
      'Ao salvar arquivos aparece um erro dizendo que o disco não tem espaço, mas eu sei que tem.',
    ],
    clues: (p) => ({
      when: 'Faz dois dias. Ligou normalmente de manhã e à tarde começou a dar problema.',
      power: 'Liga, mas é muito devagar. O logo do fabricante fica piscando por minutos.',
      restart: 'Tentei reiniciar mas ficou numa tela preta por muito tempo.',
      accident: 'Não caiu, mas tivemos uma queda de energia ontem.',
      devices: 'Os outros computadores aqui funcionam normalmente.',
      popups: 'Apareceu uma mensagem dizendo "disco com erros" e pedindo para executar o chkdsk.',
      files: 'Sumiu a pasta de documentos inteira. Estou desesperado.',
      model: `É um notebook de ${p.model} polegadas.`,
    }),
  },
  malware: {
    dept: 'software',
    intros: [
      'Cliquei num link estranho e sumiram meus arquivos.',
      'Recebi um e-mail do banco, cliquei no link e agora aparecem janelinhas o tempo todo.',
      'Baixei um programa grátis e agora o PC está lento e cheio de propaganda.',
      'Fui ver um filme online e agora o meu computador não para de abrir abas de cassino.',
      'Acho que tenho um vírus. Apareceu um aviso pedindo dinheiro para eu ver as minhas fotos.',
      'O mouse mexe sozinho de vez em quando e o PC está se arrastando.',
      'Instalei um software de produtividade e agora aparece propaganda em todo lugar.',
      'Minha sobrinha usou o computador e agora aparecem ícones estranhos na área de trabalho.',
      'O antivírus foi desativado sozinho e não consigo reativá-lo.',
      'Apareceu uma mensagem dizendo que meu IP foi banido por atividade suspeita.',
    ],
    clues: () => ({
      when: 'Ontem à noite, logo depois de clicar num e-mail dizendo que eu ganhei um prêmio.',
      power: 'Liga, mas demora uma eternidade e abre janelas sozinho.',
      restart: 'Reiniciei, mas as janelinhas voltam.',
      accident: 'Não, o aparelho nunca caiu nem nada.',
      devices: 'O celular está normal. Só o computador está esquisito.',
      popups: 'Sim! Aparecem propagandas e um aviso pedindo pagamento para eu recuperar meus arquivos.',
      files: 'Minhas fotos e documentos sumiram ou ficaram com um nome esquisito.',
      model: 'Não sei dizer o modelo, mas é um notebook.',
    }),
  },
  password: {
    dept: 'software',
    intros: [
      'Esqueci a senha do Windows e não consigo entrar no computador.',
      'Minha conta foi bloqueada depois de muitas tentativas de senha errada.',
      'Troquei a senha e agora não lembro qual é a nova. Preciso entrar urgente.',
      'O computador foi para a manutenção e voltou com uma senha que não é minha.',
      'Saí de férias, voltei e o sistema não aceita mais minha senha de jeito nenhum.',
      'Meu usuário foi desativado pela TI sem aviso e não consigo mais entrar.',
    ],
    clues: () => ({
      when: 'Hoje de manhã ao tentar ligar para trabalhar.',
      power: 'Liga normal, mas para na tela de login.',
      restart: 'Tentei reiniciar várias vezes, não adianta.',
      accident: 'Não, não aconteceu nada. Só que não aceita mais minha senha.',
      devices: 'O celular funciona bem, só o PC não deixa entrar.',
      popups: 'Só aparece "senha incorreta" toda vez que tento.',
      files: 'Espero que meus arquivos estejam lá quando eu conseguir entrar.',
      model: 'É o computador corporativo padrão da empresa.',
    }),
  },
  wifi: {
    dept: 'network',
    intros: [
      'O Wi-Fi não conecta de jeito nenhum.',
      'Minha internet parou de funcionar no notebook e eu não consigo abrir nada.',
      'Aparece um aviso amarelo de "sem acesso à internet" e não carrega página nenhuma.',
      'Consigo entrar na rede de casa, mas diz sempre que está sem internet. Podem ajudar?',
      'Trabalho de casa e a minha rede simplesmente desapareceu deste computador.',
      'A luz da internet está piscando, mas não abre site nenhum aqui.',
      'O notebook conecta no Wi-Fi mas fica carregando para sempre.',
      'Minha velocidade de internet caiu muito. Antes era rápida, agora está caindo tudo.',
      'Consigo usar o Wi-Fi no celular mas no notebook não funciona.',
      'O notebook conectava na rede da empresa mas hoje simplesmente parou.',
    ],
    clues: (p) => ({
      when: 'Parou ontem à noite, depois que a energia caiu aqui em casa.',
      power: 'Liga normal e o sistema abre numa boa.',
      restart: 'Reiniciei e nada mudou.',
      accident: 'Não, está inteiro, nunca caiu.',
      devices: p.cause === 'ip'
        ? 'O celular conecta normal. Só esse computador não pega.'
        : 'Nenhum aparelho conecta, e a luz do roteador está piscando vermelha.',
      popups: 'Só aparece o aviso amarelo de "sem acesso à internet".',
      files: 'Meus arquivos estão todos aqui.',
      model: 'É um notebook, não sei o modelo exato.',
    }),
  },
  dns: {
    dept: 'network',
    intros: [
      'A internet está conectada mas os sites não abrem. Só aparece "DNS não encontrado".',
      'Algumas páginas abrem e outras não. É muito aleatório.',
      'Meu computador navega normalmente pelo IP mas não pelos nomes dos sites.',
      'O navegador diz "Hmm, não consigo acessar este site" em todo lugar.',
      'Só o e-mail da empresa funciona aqui. Sites externos não carregam.',
      'A rede está ok mas os funcionários não conseguem acessar o servidor interno pelo nome.',
    ],
    clues: (p) => ({
      when: 'Desde ontem após a atualização do roteador que a TI fez.',
      power: 'O computador funciona perfeitamente, apenas a navegação que falha.',
      restart: 'Reiniciei o computador e o roteador, não adiantou.',
      accident: 'Nenhum acidente. Só a atualização que foi feita.',
      devices: p.cause === 'ip'
        ? 'No celular por 4G tudo funciona. Na rede Wi-Fi também falha.'
        : 'Todos os computadores da rede têm o mesmo problema.',
      popups: 'Só a mensagem de DNS não encontrado.',
      files: 'Os arquivos internos estão acessíveis normalmente.',
      model: 'São os desktops padrão da empresa.',
    }),
  },
};

const FALLBACK = [
  'Hmm, não sei explicar direito, sou leigo nisso.',
  'Não entendi bem a pergunta... pode perguntar de outro jeito?',
  'Isso eu não sei dizer, desculpa!',
  'Desculpe, a tecnologia passa meio batido por mim.',
  'Não faço a menor ideia.',
  'Prefiro não arriscar uma resposta e te confundir mais.',
  'Essa parte técnica foge do meu entendimento.',
];
const KEYWORDS = [
  ['accident', ['acidente', 'cair', 'caiu', 'queda', 'bateu', 'molhou', 'agua', 'derram', 'pancada', 'queda de energia', 'energia']],
  ['devices', ['outro', 'aparelho', 'celular', 'telefone', 'tv', 'tablet', 'ipad']],
  ['popups', ['janela', 'mensagem', 'aviso', 'estranh', 'propaganda', 'erro', 'virus', 'tela azul', 'bsod', 'crash']],
  ['files', ['arquivo', 'pasta', 'foto', 'documento', 'sumiu', 'perdi', 'desapareceu']],
  ['restart', ['reinici', 'reset', 'desligar', 'reiniciar', 'reboot']],
  ['when', ['quando', 'comec', 'desde', 'horas', 'aconteceu', 'inicio']],
  ['model', ['modelo', 'polegada', 'tamanho', 'marca', 'qual', 'fabricante']],
  ['power', ['liga', 'acende', 'boot', 'funciona', 'imagem', 'tela', 'video', 'ecra', 'carrega', 'lento']],
];
const norm = (s) => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

// ============================================================================
// 2) ESTADO
// ============================================================================
const players = new Map();
const clients = new Map();
const items = new Map();
const sstate = new Map();
let waitList = [];
let nextClientId = 1, nextItemId = 1, nextSid = 1, osCounter = 0, roleCursor = 0;
let worldDirty = true, lastWorldSent = 0;
const game = { score: 0, delivered: 0, routed: 0, routedOk: 0, nextClientAt: 0 };

function resetStations() {
  sstate.clear();
  for (const s of S.STATIONS) {
    if (s.type === 'table') sstate.set(s.id, { slots: new Array(s.slots).fill(null) });
    else if (s.type === 'bench') sstate.set(s.id, { item: null, phase: 0, inspected: false, mismatch: false, sim: null });
    else sstate.set(s.id, {});
  }
}
function resetGame() {
  clients.clear(); items.clear(); waitList = []; resetStations();
  for (const p of players.values()) { p.carry = null; p.ui = null; p.chatClient = null; }
  Object.assign(game, { score: 0, delivered: 0, routed: 0, routedOk: 0, nextClientAt: Date.now() + CFG.FIRST_CLIENT });
  worldDirty = true;
}
resetGame();

// ============================================================================
// 3) HELPERS
// ============================================================================
const rnd = (a) => a[Math.floor(Math.random() * a.length)];
const shuffle = (a) => a.map((v) => [Math.random(), v]).sort((x, y) => x[0] - y[0]).map((x) => x[1]);
const stationById = (id) => S.STATIONS.find((s) => s.id === id);
const osLabel = (n) => 'OS-' + String(n).padStart(4, '0');
const label = (role) => S.ROLE_LABEL[role];
const deptIndex = (d) => S.DEPTS.indexOf(d);

function itemCode(it) { return !it ? 0 : it.repaired ? 4 : deptIndex(it.dept) + 1; }
function itemInfo(it) {
  return { id: it.id, os: osLabel(it.os), customer: it.customer, summary: it.summary, model: it.model,
    dept: it.dept, repaired: it.repaired, mistakes: it.mistakes, misroutes: it.misroutes };
}
function roleCount(role) { let n = 0; for (const p of players.values()) if (p.role === role) n++; return n; }
function rosterPayload() {
  const slots = {};
  for (const r of S.ROLES) slots[r] = { used: roleCount(r), max: S.ROLE_LIMITS[r] };
  return { players: [...players.values()].map((p) => ({ sid: p.sid, name: p.name, role: p.role, custom: p.custom })), slots };
}
const broadcastRoster = () => io.emit('roster', rosterPayload());
const sys = (text) => io.emit('chat', { sys: true, text, t: Date.now() });
const deny = (p, code, msg) => p.socket.emit('denied', { code, msg });
const info = (p, msg) => p.socket.emit('info', { msg });
const playerBySid = (sid) => [...players.values()].find((p) => p.sid === sid) || null;
const sanitizeName = (n) => (String(n || '').replace(/[^\p{L}\p{N} _\-]/gu, '').trim().slice(0, 16)) || 'Colega' + Math.floor(Math.random() * 900 + 100);
const cleanText = (t, max) => String(t || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
const notifyDept = (dept, payload) => io.to('role:' + dept).emit('notify_task', payload);

function tableFree(id) { return sstate.get(id).slots.indexOf(null); }
function pendingInTriage() {
  const out = { hardware: 0, software: 0, network: 0 };
  for (const id of sstate.get('T_in').slots) if (id) out[items.get(id).dept]++;
  return out;
}

// ============================================================================
// 4) MATCHMAKING DE FUNÇÕES
// ============================================================================
function demandByRole() {
  const d = { reception: waitList.length, hardware: 0, software: 0, network: 0 };
  for (const it of items.values()) { if (it.repaired) d.reception++; else d[it.dept]++; }
  return d;
}

function isSoloPlayer() {
  return players.size === 0 || (players.size === 1);
}

function pickRole() {
  // Never assign reception to the first (or only) player
  const techRoles = ['hardware', 'software', 'network'];
  if (players.size === 0) {
    return rnd(techRoles);
  }

  const counts = {};
  for (const r of S.ROLES) counts[r] = roleCount(r);

  // If only one player so far (this would be the 2nd joining), still prefer tech
  if (players.size === 1) {
    const open = techRoles.filter((r) => counts[r] < S.ROLE_LIMITS[r]);
    const empty = open.filter((r) => counts[r] === 0);
    return rnd(empty.length ? empty : open);
  }

  const open = S.ROLES.filter((r) => counts[r] < S.ROLE_LIMITS[r]);
  const empty = open.filter((r) => counts[r] === 0);
  const pool = empty.length ? empty : open;
  const dem = demandByRole();
  const score = (r) => (empty.length ? dem[r] : (dem[r] + 0.5) / counts[r]);
  let best = -Infinity, tied = [];
  for (const r of pool) {
    const sc = score(r);
    if (sc > best + 1e-9) { best = sc; tied = [r]; } else if (Math.abs(sc - best) <= 1e-9) tied.push(r);
  }
  const n = S.ROLES.length;
  tied.sort((a, b) => ((S.ROLES.indexOf(a) - roleCursor + n) % n) - ((S.ROLES.indexOf(b) - roleCursor + n) % n));
  roleCursor = (S.ROLES.indexOf(tied[0]) + 1) % n;
  return tied[0];
}

function setRole(p, role) {
  if (p.role) p.socket.leave('role:' + p.role);
  p.role = role;
  p.socket.join('role:' + role);
}
function rebalanceRoles() {
  const techCount = ['hardware', 'software', 'network'].reduce((acc, r) => acc + roleCount(r), 0);
  // If only 1 player left, make sure they're not forced to reception
  if (players.size === 1) {
    const solo = [...players.values()][0];
    if (solo.role === 'reception') {
      const newRole = rnd(['hardware', 'software', 'network']);
      releaseClaim(solo); solo.ui = null; solo.socket.emit('close_station');
      setRole(solo, newRole);
      sys(`🔄 ${solo.name} foi movido(a) para ${label(newRole)} (modo solo).`);
      broadcastRoster();
    }
    return;
  }

  for (const empty of S.ROLES) {
    if (roleCount(empty) > 0) continue;
    let donor = null;
    for (const r of S.ROLES) if (roleCount(r) > 1 && (!donor || roleCount(r) > roleCount(donor))) donor = r;
    if (!donor) return;
    const c = [...players.values()].filter((p) => p.role === donor && !p.carry).sort((a, b) => b.joinedAt - a.joinedAt);
    if (!c.length) continue;
    releaseClaim(c[0]); c[0].ui = null; c[0].socket.emit('close_station');
    setRole(c[0], empty);
    sys(`🔄 ${c[0].name} foi transferido(a) para ${label(empty)} para cobrir a equipe.`);
  }
}

// ============================================================================
// 5) CLIENTES NPC E CHAT
// ============================================================================
function randomLook() {
  const C = S.CUSTOMIZATION, k = (o) => rnd(Object.keys(o));
  return S.sanitizeCustom({ base: rnd(C.base), shirt: k(C.shirt), pants: k(C.pants), hair: k(C.hair), skin: k(C.skin), accessory: rnd(C.accessory) });
}

function getSoloDept() {
  // Returns the department of the solo player, or null if not applicable
  if (players.size !== 1) return null;
  const solo = [...players.values()][0];
  return S.DEPTS.includes(solo.role) ? solo.role : null;
}

function addClient(now) {
  const soloDept = getSoloDept();
  // In solo mode, only generate problems for the player's department
  let eligibleKeys;
  if (soloDept) {
    eligibleKeys = Object.keys(PROBLEMS).filter((k) => PROBLEMS[k].dept === soloDept);
    if (!eligibleKeys.length) eligibleKeys = Object.keys(PROBLEMS);
  } else {
    eligibleKeys = Object.keys(PROBLEMS);
  }

  const key = rnd(eligibleKeys);
  const pr = PROBLEMS[key];
  const params = { model: rnd(['14', '15.6', '17']), cause: rnd(['ip', 'router']) };
  const taken = new Set([...clients.values()].map((c) => c.name));
  const name = rnd(NAMES.filter((n) => !taken.has(n)).concat(NAMES.slice(0, 1)));
  const c = { id: nextClientId++, name, look: randomLook(), problem: key, params, clues: pr.clues(params),
    chat: [{ from: 'client', text: rnd(pr.intros) }], status: 'waiting', claimedBy: null };
  clients.set(c.id, c);
  waitList.push(c.id);
  worldDirty = true;
  io.to('role:reception').emit('client_arrived', { customer: c.name, waiting: waitList.length });
}

function npcReply(c, text) {
  const t = norm(text);
  for (const [topic, words] of KEYWORDS) {
    if (words.some((w) => t.includes(w))) return c.clues[topic] || rnd(FALLBACK);
  }
  if (/\b(ola|oi|bom dia|boa tarde|boa noite)\b/.test(t)) return 'Olá! Pode me ajudar, por favor?';
  return rnd(FALLBACK);
}

function releaseClaim(p) {
  if (!p.chatClient) return;
  const c = clients.get(p.chatClient);
  if (c && c.claimedBy === p.sid) c.claimedBy = null;
  p.chatClient = null;
  worldDirty = true;
}

// ============================================================================
// 6) SIMULAÇÕES DE BANCADA
// ============================================================================
const MAL_FILES = [
  ['fatura_banco.pdf.exe', 'Origem: anexo de e-mail de phishing. Tenta cifrar documentos.'],
  ['atualizacao_flash.bat', 'Comportamento: comunica com um servidor desconhecido.'],
  ['cripto_miner.dll', 'Comportamento: consome CPU em segundo plano para minerar moedas.'],
  ['senha_roubada.vbs', 'Comportamento: copia senhas salvas no navegador.'],
  ['limpador_gratis.exe', 'Origem: site suspeito. Instala adware e desativa antivírus.'],
];
const OK_FILES = [
  ['driver_audio.sys', 'Assinado digitalmente pelo fabricante. Sem comportamento suspeito.'],
  ['updater_oficial.exe', 'Assinado digitalmente. Atualizador legítimo do sistema.'],
  ['backup_agendado.bat', 'Script criado pelo próprio usuário. Sem comunicação externa.'],
];

// RAM minigame steps
const RAM_STEPS = ['Verificar slots com CPU-Z', 'Remover pente com falha', 'Instalar pente novo', 'Testar com MemTest'];
// Storage minigame steps  
const STORAGE_STEPS = ['Executar SMART check', 'Criar backup dos dados', 'Formatar e reinstalar SO', 'Restaurar arquivos de backup'];

function initSim(it) {
  switch (it.problem) {
    case 'screen':
      return { type: 'screen', screws: [0, 0, 0, 0], removed: false, installed: null, connected: false };
    case 'ram':
      return { type: 'ram', step: 0 };
    case 'storage':
      return { type: 'storage', step: 0 };
    case 'malware': {
      const variant = rnd(['adware', 'ransomware', 'optimization']);
      const mal = shuffle(MAL_FILES).slice(0, 3).map(([name, note]) => ({ name, note, mal: true, risk: 'Alto' }));
      const ok = shuffle(OK_FILES).slice(0, 2).map(([name, note]) => ({ name, note, mal: false, risk: 'Médio' }));
      const files = shuffle(mal.concat(ok)).map((f, i) => ({ id: 'f' + (i + 1), q: false, ...f }));
      return { type: 'malware', variant, phase: 'desktop', popups: variant === 'adware' ? 5 : 1, scanEnds: 0, files };
    }
    case 'password':
      return { type: 'password', step: 0, verified: false };
    case 'wifi':
      return { type: 'wifi', cause: it.params.cause, ipFixed: false, routerFixed: false, log: ['Pronto. Use as ferramentas para diagnosticar.'] };
    case 'dns':
      return { type: 'dns', cause: it.params.cause, dnsFixed: false, log: ['Pronto. Use as ferramentas para diagnosticar o DNS.'] };
  }
  return null;
}

const wifiFixed = (s) => (s.cause === 'ip' ? s.ipFixed : s.routerFixed);
const wifiLog = (s, line) => { s.log.push(line); if (s.log.length > 10) s.log.shift(); };

const SIMS = {
  screen(sim, it, act, arg) {
    switch (act) {
      case 'unscrew': {
        const i = Number(arg);
        if (!Number.isInteger(i) || i < 0 || i > 3) return { ok: false, msg: 'Parafuso inválido.' };
        if (sim.removed) return { ok: false, msg: 'A tela já foi retirada.' };
        if (sim.screws[i]) return { ok: false, msg: 'Esse parafuso já foi retirado.' };
        sim.screws[i] = 1; return { ok: true };
      }
      case 'remove':
        if (sim.removed) return { ok: false, msg: 'A tela antiga já saiu.' };
        if (!sim.screws.every(Boolean)) return { ok: false, msg: 'Ainda há parafusos prendendo a tela.' };
        sim.removed = true; return { ok: true };
      case 'choose':
        if (!sim.removed) return { ok: false, msg: 'Remova a tela antiga primeiro.' };
        if (sim.installed) return { ok: false, msg: 'Já há uma tela instalada.' };
        if (!S.SCREEN_OPTIONS.some((o) => o.key === arg)) return { ok: false, msg: 'Peça inexistente.' };
        if (arg !== it.params.model) return { ok: false, mistake: true, msg: `Essa tela não encaixa neste ${it.model}.` };
        sim.installed = arg; return { ok: true };
      case 'connect':
        if (!sim.installed) return { ok: false, msg: 'Instale a nova tela primeiro.' };
        sim.connected = true; return { ok: true };
      case 'test':
        if (!sim.connected) return { ok: false, msg: 'Ligue o cabo de vídeo antes de testar.' };
        return { ok: true, done: true };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  ram(sim, it, act) {
    const steps = RAM_STEPS;
    if (act === 'next') {
      if (sim.step >= steps.length - 1) return { ok: true, done: true };
      sim.step++; return { ok: true };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  storage(sim, it, act) {
    const steps = STORAGE_STEPS;
    if (act === 'next') {
      if (sim.step >= steps.length - 1) return { ok: true, done: true };
      sim.step++; return { ok: true };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  malware(sim, it, act, arg, now) {
    switch (act) {
      case 'close_popup': sim.popups = Math.max(0, sim.popups - 1); return { ok: true };
      case 'open_av':
        if (sim.phase !== 'desktop') return { ok: false, msg: 'O antivírus já está aberto.' };
        sim.phase = 'av'; return { ok: true };
      case 'run_scan':
        if (sim.phase !== 'av') return { ok: false, msg: 'Abra o antivírus primeiro.' };
        sim.phase = 'scanning'; sim.scanEnds = now + CFG.SCAN_MS; return { ok: true };
      case 'quarantine': {
        if (sim.phase !== 'results') return { ok: false, msg: 'Aguarde o fim da verificação.' };
        const f = sim.files.find((x) => x.id === arg);
        if (!f) return { ok: false, msg: 'Arquivo inexistente.' };
        if (f.q) return { ok: false, msg: 'Já está em quarentena.' };
        if (!f.mal) return { ok: false, mistake: true, msg: `«${f.name}» é um arquivo legítimo! Quarentena cancelada.` };
        f.q = true; return { ok: true };
      }
      case 'finish':
        if (sim.phase !== 'results') return { ok: false, msg: 'Execute a verificação primeiro.' };
        if (!sim.files.every((f) => !f.mal || f.q)) return { ok: false, msg: 'Ainda há ameaças ativas no sistema.' };
        return { ok: true, done: true };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  password(sim, it, act) {
    // Step 0: verify identity, Step 1: reset password, Step 2: confirm access
    switch (act) {
      case 'verify_identity':
        if (sim.step !== 0) return { ok: false, msg: 'Identidade já verificada.' };
        sim.verified = true; sim.step = 1; return { ok: true };
      case 'reset_password':
        if (sim.step !== 1) return { ok: false, msg: 'Verifique a identidade primeiro.' };
        sim.step = 2; return { ok: true };
      case 'confirm_access':
        if (sim.step !== 2) return { ok: false, msg: 'Redefina a senha antes de confirmar.' };
        return { ok: true, done: true };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  wifi(sim, it, act, arg) {
    switch (act) {
      case 'ipconfig':
        wifiLog(sim, '> ipconfig');
        wifiLog(sim, `  IPv4: ${wifiIp(sim)}   Gateway: 192.168.1.1`);
        return { ok: true };
      case 'ping': {
        const t = arg === 'internet' ? 'internet' : 'gateway';
        wifiLog(sim, `> ping ${t === 'internet' ? '8.8.8.8' : '192.168.1.1'}`);
        let okp;
        if (sim.cause === 'ip' && !sim.ipFixed) okp = false;
        else if (sim.cause === 'router' && !sim.routerFixed) okp = t === 'gateway';
        else okp = true;
        wifiLog(sim, okp ? '  Resposta recebida (4/4).' : (sim.cause === 'ip' ? '  Destino inacessível.' : '  Tempo esgotado.'));
        return { ok: true };
      }
      case 'renew_ip':
        if (sim.cause === 'ip' && !sim.ipFixed) { sim.ipFixed = true; wifiLog(sim, '> DHCP: novo IP 192.168.1.42 atribuído.'); }
        else wifiLog(sim, '> DHCP: IP renovado (sem alterações).');
        return { ok: true };
      case 'restart_router':
        if (sim.cause === 'router' && !sim.routerFixed) { sim.routerFixed = true; wifiLog(sim, '> Roteador reiniciado. WAN: online.'); return { ok: true }; }
        wifiLog(sim, '> Roteador reiniciado (estava saudável).');
        return { ok: false, mistake: true, msg: 'O roteador estava saudável. Reiniciá-lo derrubou a rede de todos por um instante.' };
      case 'test':
        if (wifiFixed(sim)) return { ok: true, done: true };
        wifiLog(sim, '> Teste de conexão: sem acesso à internet.');
        return { ok: false, msg: 'Ainda sem acesso à internet.' };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  dns(sim, it, act, arg) {
    switch (act) {
      case 'nslookup':
        wifiLog(sim, '> nslookup google.com');
        if (!sim.dnsFixed)
          wifiLog(sim, '  Erro: servidor DNS inacessível (192.168.1.1).');
        else
          wifiLog(sim, '  Resposta: 142.250.79.110 (OK).');
        return { ok: true };
      case 'ping_ip':
        wifiLog(sim, '> ping 8.8.8.8');
        wifiLog(sim, '  Resposta recebida (4/4). A rede IP está ok.');
        return { ok: true };
      case 'set_dns_google':
        if (!sim.dnsFixed) {
          sim.dnsFixed = true;
          wifiLog(sim, '> DNS alterado para 8.8.8.8 / 8.8.4.4 (Google).');
          wifiLog(sim, '  Flush DNS... Concluído.');
        } else {
          wifiLog(sim, '> DNS já está configurado corretamente.');
        }
        return { ok: true };
      case 'flush_dns':
        wifiLog(sim, '> ipconfig /flushdns');
        wifiLog(sim, sim.dnsFixed ? '  Cache DNS limpo com sucesso.' : '  Cache limpo, mas DNS ainda incorreto.');
        return { ok: true };
      case 'test':
        if (sim.dnsFixed) return { ok: true, done: true };
        wifiLog(sim, '> Teste: nomes de domínio ainda não resolvem.');
        return { ok: false, msg: 'Configure o DNS correto antes de testar.' };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },
};
const wifiIp = (s) => (s.cause === 'ip' && !s.ipFixed ? '169.254.23.17 (autoconfiguração)' : '192.168.1.42');

function simView(sim, now) {
  if (!sim) return null;
  switch (sim.type) {
    case 'screen':
      return { type: 'screen', screws: sim.screws, removed: sim.removed, installed: sim.installed,
        connected: sim.connected, options: S.SCREEN_OPTIONS };
    case 'ram':
      return { type: 'ram', step: sim.step, steps: RAM_STEPS };
    case 'storage':
      return { type: 'storage', step: sim.step, steps: STORAGE_STEPS };
    case 'malware':
      return { type: 'malware', variant: sim.variant, phase: sim.phase, popups: sim.popups, total: CFG.SCAN_MS,
        msLeft: sim.phase === 'scanning' ? Math.max(0, sim.scanEnds - now) : 0,
        files: sim.phase === 'results' ? sim.files.map((f) => ({ id: f.id, name: f.name, risk: f.risk, note: f.note, q: f.q })) : [] };
    case 'password':
      return { type: 'password', step: sim.step, verified: sim.verified };
    case 'wifi':
      return { type: 'wifi', ip: wifiIp(sim), gateway: '192.168.1.1',
        adapter: wifiFixed(sim) ? 'Conectado' : 'Sem acesso à internet',
        wan: sim.cause === 'router' && !sim.routerFixed ? 'Sem sinal' : 'Online', log: sim.log };
    case 'dns':
      return { type: 'dns', dnsFixed: sim.dnsFixed,
        currentDns: sim.dnsFixed ? '8.8.8.8 / 8.8.4.4' : '192.168.1.1 (inválido)',
        log: sim.log };
  }
  return null;
}

// ============================================================================
// 7) VISTAS DE ESTAÇÃO
// ============================================================================
function viewFor(p, s) {
  const st = sstate.get(s.id), now = Date.now();
  const base = { id: s.id, type: s.type, label: s.label, role: s.role || null };
  switch (s.type) {
    case 'counter': {
      const list = waitList.map((id) => {
        const c = clients.get(id), other = c.claimedBy && c.claimedBy !== p.sid ? playerBySid(c.claimedBy) : null;
        return { id, name: c.name, busyWith: other ? other.name : null };
      });
      const c = p.chatClient ? clients.get(p.chatClient) : null;
      const active = c && c.status === 'waiting'
        ? { id: c.id, name: c.name, chat: c.chat, os: osLabel(osCounter + 1) } : null;
      return { ...base, list, active, depts: S.DEPTS.map((d) => ({ key: d, label: label(d) })), chips: S.QUICK_QUESTIONS };
    }
    case 'bench': {
      const it = st.item ? items.get(st.item) : null;
      return { ...base, dept: s.role, phase: st.phase, inspected: st.inspected, mismatch: st.mismatch,
        actualDept: st.mismatch && it ? it.actualDept : null, actualLabel: st.mismatch && it ? label(it.actualDept) : null,
        item: it ? itemInfo(it) : null, sim: st.phase >= 2 ? simView(st.sim, now) : null };
    }
    case 'delivery': {
      const it = p.carry ? items.get(p.carry) : null;
      return { ...base, item: it ? itemInfo(it) : null };
    }
  }
  return base;
}
const sendView = (p, s) => { p.ui = s.id; p.socket.emit('open_station', viewFor(p, s)); };
function closeView(p) { p.ui = null; releaseClaim(p); p.socket.emit('close_station'); }

function stationFor(p, id, types) {
  const s = typeof id === 'string' ? stationById(id) : null;
  if (!s || !types.includes(s.type)) { deny(p, 'bad_station', 'Estação inválida.'); return null; }
  if (S.distToRect(p.x, p.z, s) > S.INTERACT_RANGE + 0.6) { deny(p, 'too_far', 'Você se afastou demais da estação.'); closeView(p); return null; }
  if (s.role && s.role !== p.role) { deny(p, 'role_not_allowed', `${label(p.role)} não pode usar «${s.label}». Só ${label(s.role)}.`); return null; }
  return s;
}
function nearestStation(p) {
  let best = null, bd = Infinity;
  for (const s of S.STATIONS) { const d = S.distToRect(p.x, p.z, s); if (d <= S.INTERACT_RANGE && d < bd) { bd = d; best = s; } }
  return best;
}

// ============================================================================
// 8) INTERAÇÃO "E"
// ============================================================================
function handleInteract(p) {
  const s = nearestStation(p);
  if (!s) return deny(p, 'no_station', 'Não há nenhuma estação ao alcance.');
  if (s.role && s.role !== p.role) {
    return deny(p, 'role_not_allowed', `${label(p.role)} não pode usar «${s.label}». Só ${label(s.role)}.`);
  }
  const st = sstate.get(s.id);

  switch (s.type) {
    case 'counter': return sendView(p, s);

    case 'table': {
      if (s.kind === 'in') {
        if (p.role === 'reception') return deny(p, 'not_tech', 'A Recepção deixa a OS no sistema; só técnicos recolhem máquinas aqui.');
        if (p.carry) return deny(p, 'hands_full', 'Você já está carregando uma máquina.');
        const idx = st.slots.findIndex((id) => id && items.get(id).dept === p.role);
        if (idx < 0) return deny(p, 'nothing_for_you', `Nenhuma máquina encaminhada para ${label(p.role)}.`);
        p.carry = st.slots[idx]; st.slots[idx] = null;
      } else {
        if (p.carry) {
          if (p.role === 'reception') return deny(p, 'hands_full', 'Você já está carregando um PC.');
          if (!items.get(p.carry).repaired) return deny(p, 'not_repaired', 'Este PC ainda não foi reparado.');
          const idx = tableFree(s.id);
          if (idx < 0) return deny(p, 'table_full', 'A mesa de saída está cheia.');
          st.slots[idx] = p.carry; p.carry = null;
        } else {
          if (p.role !== 'reception') return deny(p, 'only_reception', 'Só a Recepção recolhe PCs reparados aqui.');
          const idx = st.slots.findIndex((x) => x !== null);
          if (idx < 0) return deny(p, 'table_empty', 'Não há PCs prontos para entrega.');
          p.carry = st.slots[idx]; st.slots[idx] = null;
        }
      }
      worldDirty = true; return;
    }

    case 'bench': {
      if (p.carry) {
        const it = items.get(p.carry);
        if (st.phase !== 0) return deny(p, 'bench_busy', 'A bancada já está ocupada.');
        if (it.repaired) return deny(p, 'already_done', 'Este PC já está reparado. Leve-o à Mesa de Saída.');
        if (it.dept !== s.role) return deny(p, 'wrong_dept', `Esta máquina foi encaminhada para ${label(it.dept)}.`);
        Object.assign(st, { item: p.carry, phase: 1, inspected: false, mismatch: false, sim: null });
        p.carry = null; worldDirty = true;
        return sendView(p, s);
      }
      if (st.phase === 0) return deny(p, 'bench_empty', 'Traga uma máquina da Mesa de Triagem.');
      return sendView(p, s);
    }

    case 'delivery': {
      if (!p.carry) return deny(p, 'no_item', 'Traga um PC reparado da Mesa de Saída.');
      return sendView(p, s);
    }
  }
}

// ============================================================================
// 9) AÇÕES — RECEPÇÃO
// ============================================================================
function actChatOpen(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  const c = clients.get(d.clientId);
  if (!c || c.status !== 'waiting') { deny(p, 'gone', 'Esse cliente já foi atendido.'); return sendView(p, s); }
  if (c.claimedBy && c.claimedBy !== p.sid && playerBySid(c.claimedBy)) {
    deny(p, 'busy', 'Outro colega já está atendendo este cliente.'); return sendView(p, s);
  }
  releaseClaim(p);
  c.claimedBy = p.sid; p.chatClient = c.id; worldDirty = true;
  sendView(p, s);
}
function actChatRelease(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  releaseClaim(p); sendView(p, s);
}
function actChatSay(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  const c = p.chatClient ? clients.get(p.chatClient) : null;
  if (!c || c.status !== 'waiting') return deny(p, 'no_chat', 'Abra primeiro a conversa com um cliente.');
  const text = cleanText(d.text, 120);
  if (!text) return;
  c.chat.push({ from: 'rec', text });
  const reply = npcReply(c, text);
  sendView(p, s);
  setTimeout(() => {
    if (c.status !== 'waiting') return;
    c.chat.push({ from: 'client', text: reply });
    if (c.chat.length > 40) c.chat.splice(0, c.chat.length - 40);
    if (p.ui === 'counter' && p.chatClient === c.id) sendView(p, s);
  }, 600 + Math.random() * 500);
}

function actOsSubmit(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  const c = p.chatClient ? clients.get(p.chatClient) : null;
  if (!c || c.status !== 'waiting') return deny(p, 'no_chat', 'Abra primeiro a conversa com um cliente.');
  const summary = cleanText(d.summary, 160);
  if (summary.length < 5) return deny(p, 'bad_summary', 'Descreva o problema na OS (mínimo 5 caracteres).');
  if (!S.DEPTS.includes(d.dept)) return deny(p, 'bad_dept', 'Escolha o departamento de destino.');
  const slot = tableFree('T_in');
  if (slot < 0) return deny(p, 'triage_full', 'A Mesa de Triagem está cheia. Aguarde os técnicos recolherem máquinas.');

  const it = { id: nextItemId++, os: ++osCounter, clientId: c.id, customer: c.name, problem: c.problem, params: c.params,
    actualDept: PROBLEMS[c.problem].dept, dept: d.dept, summary, model: `Notebook ${c.params.model}″`,
    misroutes: 0, mistakes: 0, repaired: false };
  items.set(it.id, it);
  sstate.get('T_in').slots[slot] = it.id;
  c.status = 'inService'; c.claimedBy = null; p.chatClient = null;
  waitList = waitList.filter((id) => id !== c.id);

  notifyDept(d.dept, { os: osLabel(it.os), customer: c.name, dept: d.dept,
    text: 'Nova máquina aguardando reparo na bancada de triagem', pending: pendingInTriage()[d.dept] });
  info(p, `${osLabel(it.os)} enviada para ${label(d.dept)}.`);
  worldDirty = true;
  sendView(p, s);
}

function actDeliver(p, d) {
  const s = stationFor(p, d.station, ['delivery']); if (!s) return;
  if (!p.carry) return deny(p, 'no_item', 'Você não está carregando nenhum PC.');
  const it = items.get(p.carry);
  if (!it.repaired) return deny(p, 'not_ready', 'Este PC ainda não está reparado.');
  const stars = Math.max(1, 5 - Math.floor(it.mistakes / 2) - it.misroutes);
  game.score += stars * CFG.SCORE_PER_STAR; game.delivered++;
  items.delete(it.id); clients.delete(it.clientId); p.carry = null;
  io.to('role:reception').emit('delivered', { customer: it.customer, stars, text: THANKS[stars - 1], os: osLabel(it.os) });
  worldDirty = true;
  closeView(p);
}

// ============================================================================
// 10) AÇÕES — BANCADAS
// ============================================================================
function actInspect(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (st.phase !== 1 || st.inspected) return deny(p, 'bad_phase', 'Nada para inspecionar.');
  const it = items.get(st.item);
  st.inspected = true; game.routed++;
  if (it.actualDept === s.role) { game.routedOk++; st.mismatch = false; st.sim = initSim(it); st.phase = 2; }
  else st.mismatch = true;
  worldDirty = true; sendView(p, s);
}

function actReroute(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (st.phase !== 1 || !st.mismatch) return deny(p, 'bad_phase', 'Você só pode encaminhar após uma inspeção que revele triagem errada.');
  if (!S.DEPTS.includes(d.dept) || d.dept === s.role) return deny(p, 'bad_dept', 'Departamento inválido.');
  const slot = tableFree('T_in');
  if (slot < 0) return deny(p, 'triage_full', 'A Mesa de Triagem está cheia.');
  const it = items.get(st.item);
  it.dept = d.dept; it.misroutes++; game.score -= CFG.PEN_MISROUTE;
  sstate.get('T_in').slots[slot] = it.id;
  Object.assign(st, { item: null, phase: 0, inspected: false, mismatch: false, sim: null });
  notifyDept(d.dept, { os: osLabel(it.os), customer: it.customer, dept: d.dept,
    text: 'Nova máquina aguardando reparo na bancada de triagem', pending: pendingInTriage()[d.dept] });
  io.to('role:reception').emit('triage_feedback', { os: osLabel(it.os), from: label(s.role), to: label(d.dept),
    text: `${osLabel(it.os)} foi encaminhada de ${label(s.role)} para ${label(d.dept)}: a triagem inicial estava incorreta.` });
  worldDirty = true; closeView(p);
}

function actSim(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (st.phase !== 2 || !st.sim) return deny(p, 'bad_phase', 'Inspecione o equipamento primeiro.');
  const it = items.get(st.item);
  const fn = SIMS[st.sim.type];
  const r = fn(st.sim, it, String(d.act || ''), d.arg, Date.now());
  if (r.mistake) { it.mistakes++; game.score -= CFG.PEN_MISTAKE; worldDirty = true; }
  if (!r.ok && r.msg) deny(p, 'sim', r.msg);
  if (r.done) { st.phase = 3; it.repaired = true; worldDirty = true; }
  sendView(p, s);
}

function actBenchCollect(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (p.carry) return deny(p, 'hands_full', 'Você já está carregando uma máquina.');
  if (st.phase === 0) return deny(p, 'bench_empty', 'A bancada está vazia.');
  if (st.phase === 2) return deny(p, 'in_progress', 'Termine o reparo antes de retirar a máquina.');
  if (st.phase === 1 && st.inspected) return deny(p, 'must_reroute', 'Esta máquina precisa ser encaminhada.');
  p.carry = st.item;
  Object.assign(st, { item: null, phase: 0, inspected: false, mismatch: false, sim: null });
  worldDirty = true; closeView(p);
}

// ============================================================================
// 11) LÓGICA PERIÓDICA (IA e Game Loop)
// ============================================================================
function updateGame(now) {
  if (players.size === 0) return;

  if (now >= game.nextClientAt) {
    game.nextClientAt = now + CFG.CLIENT_EVERY;
    if (waitList.length < CFG.MAX_WAIT) addClient(now);
  }

  // ==========================================================
  // IA DA RECEPÇÃO — ativa quando ninguém está na recepção
  // ==========================================================
  if (roleCount('reception') === 0) {
    if (waitList.length > 0) {
      const slot = tableFree('T_in');
      if (slot >= 0) {
        const cid = waitList.shift();
        const c = clients.get(cid);
        const realDept = PROBLEMS[c.problem].dept;

        const it = { id: nextItemId++, os: ++osCounter, clientId: c.id, customer: c.name, problem: c.problem, params: c.params,
          actualDept: realDept, dept: realDept, summary: 'Triagem Automática (IA da Recepção)', model: `Notebook ${c.params.model}″`,
          misroutes: 0, mistakes: 0, repaired: false };

        items.set(it.id, it);
        sstate.get('T_in').slots[slot] = it.id;
        c.status = 'inService';

        notifyDept(realDept, { os: osLabel(it.os), customer: c.name, dept: realDept,
          text: 'Nova máquina aguardando reparo (Auto-Recepção)', pending: pendingInTriage()[realDept] });

        io.emit('chat', { sys: true, text: `🤖 IA atendeu ${c.name} e abriu ${osLabel(it.os)} para ${label(realDept)}.`, t: Date.now() });
        worldDirty = true;
      }
    }

    const outSlots = sstate.get('T_out').slots;
    for (let i = 0; i < outSlots.length; i++) {
      if (outSlots[i]) {
        const it = items.get(outSlots[i]);
        if (it && it.repaired) {
          game.score += 5 * CFG.SCORE_PER_STAR;
          game.delivered++;
          io.emit('chat', { sys: true, text: `📦 A IA entregou o PC de ${it.customer} com sucesso. (+${5 * CFG.SCORE_PER_STAR} pts)`, t: Date.now() });
          items.delete(it.id);
          clients.delete(it.clientId);
          outSlots[i] = null;
          worldDirty = true;
        }
      }
    }
  }

  for (const s of S.STATIONS) {
    if (s.type !== 'bench') continue;
    const st = sstate.get(s.id);
    if (st.phase === 2 && st.sim && st.sim.type === 'malware' && st.sim.phase === 'scanning' && now >= st.sim.scanEnds) {
      st.sim.phase = 'results'; worldDirty = true;
    }
  }
}

function refreshOpenViews() {
  for (const p of players.values()) {
    if (!p.ui) continue;
    const s = stationById(p.ui);
    if (!s || (s.role && s.role !== p.role) || S.distToRect(p.x, p.z, s) > S.INTERACT_RANGE + 0.6) { closeView(p); continue; }
    if (s.type === 'delivery' && !p.carry) { closeView(p); continue; }
    p.socket.emit('open_station', viewFor(p, s));
  }
}

function worldPayload() {
  const st = {};
  for (const s of S.STATIONS) {
    const d = sstate.get(s.id);
    if (s.type === 'table') st[s.id] = d.slots.map((id) => (id ? itemCode(items.get(id)) : 0));
    else if (s.type === 'bench') st[s.id] = [d.item ? itemCode(items.get(d.item)) : 0, d.phase];
  }
  return { st, q: waitList.length, wip: items.size, dv: game.delivered, score: game.score,
    acc: game.routed ? Math.round((100 * game.routedOk) / game.routed) : null,
    tri: pendingInTriage(),
    cl: waitList.map((id) => { const c = clients.get(id); return { id, name: c.name, look: c.look, serving: !!c.claimedBy }; }) };
}

// ============================================================================
// 12) LOOP PRINCIPAL
// ============================================================================
const DT_MS = 1000 / S.TICK_RATE;
let acc = 0, prev = Date.now(), tickCount = 0;

function tick(now) {
  tickCount++;
  for (const p of players.values()) {
    const inp = p.inputs.shift();
    if (inp) { S.stepPlayer(p, inp, S.DT); p.ack = inp.seq; }
  }
  if (tickCount % 3 === 0) {
    const arr = [];
    for (const p of players.values()) {
      arr.push([p.sid, +p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2), +p.ry.toFixed(2),
        itemCode(p.carry ? items.get(p.carry) : null), p.ack]);
    }
    io.volatile.emit('snap', { t: now, p: arr });
    if (worldDirty || now - lastWorldSent > 1000) { io.emit('world', worldPayload()); worldDirty = false; lastWorldSent = now; }
  }
  if (tickCount % 6 === 0) updateGame(now);
  if (tickCount % 30 === 0) refreshOpenViews();
}
setInterval(() => {
  const now = Date.now();
  acc += now - prev; prev = now;
  if (acc > 250) acc = 250;
  while (acc >= DT_MS) { acc -= DT_MS; tick(Date.now()); }
}, 4);

// ============================================================================
// 13) SOCKET.IO
// ============================================================================
function rate(p, key, ms) { const now = Date.now(); if (now - (p[key] || 0) < ms) return false; p[key] = now; return true; }

function returnItem(itemId) {
  const it = items.get(itemId);
  if (!it) return;
  const table = it.repaired ? 'T_out' : 'T_in';
  const idx = tableFree(table);
  if (idx < 0) { items.delete(itemId); clients.delete(it.clientId); return; }
  sstate.get(table).slots[idx] = itemId;
}

io.on('connection', (socket) => {
  socket.emit('roster', rosterPayload());

  socket.on('join', (data, cb) => {
    if (typeof cb !== 'function') cb = () => {};
    if (players.has(socket.id)) return cb({ ok: false, error: 'Você já está na sala.' });
    if (players.size >= S.MAX_PLAYERS) return cb({ ok: false, error: 'Sala cheia (14/14).' });

    const used = new Set([...players.values()].map((q) => q.spawnIdx));
    let spawnIdx = 0; while (used.has(spawnIdx)) spawnIdx++;
    const sp = S.spawnPoint(spawnIdx);
    const role = pickRole();
    const p = { sid: nextSid++, socket, name: sanitizeName(data && data.name), role: null, custom: S.sanitizeCustom(data && data.custom),
      x: sp.x, y: sp.y, z: sp.z, ry: 0, carry: null, inputs: [], lastSeqIn: 0, ack: 0, ui: null, chatClient: null,
      spawnIdx, joinedAt: Date.now() };
    setRole(p, role);
    players.set(socket.id, p);

    cb({ ok: true, you: { sid: p.sid, name: p.name, role, custom: p.custom, x: p.x, y: p.y, z: p.z }, world: worldPayload() });
    broadcastRoster();
    sys(`👋 ${p.name} entrou na equipe de ${label(role)}.`);
    worldDirty = true;
  });

  socket.on('customize', (c) => {
    const p = players.get(socket.id);
    if (!p || !rate(p, 'tCustom', 400)) return;
    p.custom = S.sanitizeCustom(c);
    broadcastRoster();
  });

  socket.on('inputs', (arr) => {
    const p = players.get(socket.id);
    if (!p || !Array.isArray(arr)) return;
    for (let i = 0; i < Math.min(arr.length, 10); i++) {
      const inp = arr[i];
      if (!inp || !Number.isInteger(inp.seq) || inp.seq <= p.lastSeqIn) continue;
      if (p.inputs.length >= 15) break;
      p.lastSeqIn = inp.seq;
      p.inputs.push({ seq: inp.seq, dx: +inp.dx || 0, dz: +inp.dz || 0 });
    }
  });

  const action = (event, fn, ms = 120) => socket.on(event, (data) => {
    const p = players.get(socket.id);
    if (!p || !rate(p, 't_' + event, ms)) return;
    fn(p, data && typeof data === 'object' ? data : {});
  });
  action('interact', (p) => handleInteract(p), 150);
  action('chat_open', actChatOpen);
  action('chat_release', actChatRelease);
  action('chat_say', actChatSay, 500);
  action('os_submit', actOsSubmit, 300);
  action('deliver', actDeliver);
  action('inspect', actInspect);
  action('reroute', actReroute);
  action('sim', actSim, 100);
  action('bench_collect', actBenchCollect);
  socket.on('ui_close', () => { const p = players.get(socket.id); if (p) { p.ui = null; releaseClaim(p); } });

  socket.on('chat', (text) => {
    const p = players.get(socket.id);
    if (!p || !rate(p, 'tChat', 500)) return;
    const clean = cleanText(text, 200);
    if (clean) io.emit('chat', { name: p.name, role: p.role, text: clean, t: Date.now() });
  });
  socket.on('emote', (e) => {
    const p = players.get(socket.id);
    if (!p || !EMOTES.includes(e) || !rate(p, 'tEmote', 800)) return;
    io.emit('emote', { sid: p.sid, e });
  });

  socket.on('disconnect', () => {
    const p = players.get(socket.id);
    if (!p) return;
    releaseClaim(p);
    if (p.carry) returnItem(p.carry);
    players.delete(socket.id);
    rebalanceRoles();
    broadcastRoster();
    sys(`🚪 ${p.name} saiu.`);
    if (players.size === 0) resetGame();
    worldDirty = true;
  });
});

server.listen(PORT, () => console.log(`TI Company Simulator em http://localhost:${PORT}`));
