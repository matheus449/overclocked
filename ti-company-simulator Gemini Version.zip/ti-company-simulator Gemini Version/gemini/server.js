/**
 * server/server.js (v3) — Servidor AUTORITATIVO do TI Company Simulator
 * ----------------------------------------------------------------------------
 * Fluxo operacional (metódico, sem corrida contra o tempo):
 *
 *   NPC chega ao balcão ─► Recepção abre o chat, interroga o cliente
 *   ─► preenche a OS e escolhe o departamento ─► servidor cria o PC (ligado à OS),
 *   coloca-o na Mesa de Triagem e emite `notify_task` SÓ para a sala do departamento
 *   ─► técnico recolhe o PC, leva-o à bancada, INSPECIONA (revela se a triagem estava certa)
 *   ─► simulação 2D (tela / antivírus / rede), validada passo a passo no servidor
 *   ─► PC reparado vai para a Mesa de Saída ─► Recepção entrega ao cliente.
 *
 * Regras de ouro: o cliente envia apenas intenções; toda regra (papel, distância,
 * ordem dos passos, qual peça é a certa) é decidida e revalidada aqui.
 * ----------------------------------------------------------------------------
 */
'use strict';

const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const S = require('../shared/shared.js');

const PORT = process.env.PORT || 3000;
const app = express();
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/shared', express.static(path.join(__dirname, '..', 'shared')));
const server = http.createServer(app);
const io = new Server(server, { pingInterval: 10000, pingTimeout: 8000 });

// ============================================================================
// 1) CONFIGURAÇÃO E DADOS DE CONTEÚDO
// ============================================================================
const CFG = {
  FIRST_CLIENT: 1500, CLIENT_EVERY: 18000, MAX_WAIT: 5,
  SCAN_MS: 4000,
  PEN_MISTAKE: 5, PEN_MISROUTE: 10, SCORE_PER_STAR: 30,
};
const EMOTES = ['👍', '😅', '🔥', '🆘', '☕'];
const NAMES = ['Marta', 'Sr. Duarte', 'Inês', 'Rui', 'Dona Alice', 'Tiago', 'Beatriz', 'Prof. Lima', 'Joana', 'Carlos', 'Helena', 'Vítor'];
const THANKS = [
  'Ainda tenho dúvidas se vão resolver... mas ok.',
  'Resolveram, mas demorou mais do que eu esperava.',
  'Tudo funcionando. Obrigado!',
  'Ficou ótimo, muito obrigado pela atenção!',
  'Atendimento impecável! Voltarei sempre!',
];

/**
 * Catálogo de problemas. Para acrescentar um novo: 1) entrada aqui (departamento real,
 * falas, pistas); 2) um "simulador" em SIMS; 3) um renderer em ui.js.
 */
const PROBLEMS = {
  screen: {
    dept: 'hardware',
    intros: [
      'Deixei o PC cair e a tela rachou.',
      'Meu notebook caiu da mesa e agora a tela está toda riscada, com uma mancha preta no canto.',
      'Sentei em cima da mochila sem querer e a tela ficou toda trincada.',
    ],
    clues: (p) => ({
      when: 'Foi hoje de manhã. O notebook escorregou da mesa e caiu no chão.',
      power: 'Liga normal, a luzinha acende e dá pra ouvir o ventilador, mas a imagem está toda quebrada.',
      restart: 'Reiniciei duas vezes e continua igual.',
      accident: 'Sim! Ele caiu da mesa, de uns 70 centímetros.',
      devices: 'Quando ligo na TV da sala a imagem aparece certinha.',
      popups: 'Não aparece nada estranho, só a tela riscada mesmo.',
      files: 'Meus arquivos estão todos aí, pelo que consegui ver.',
      model: `É um notebook de ${p.model} polegadas.`,
    }),
  },
  malware: {
    dept: 'software',
    intros: [
      'Cliquei num link estranho e sumiram meus arquivos.',
      'Recebi um e-mail do banco, cliquei no link e agora aparecem janelinhas o tempo todo.',
      'Baixei um programa grátis e agora o PC está lento e cheio de propaganda.',
    ],
    clues: () => ({
      when: 'Ontem à noite, logo depois de clicar num e-mail dizendo que eu ganhei um prêmio.',
      power: 'Liga, mas demora uma eternidade e abre janelas sozinho.',
      restart: 'Reiniciei, mas as janelinhas voltam.',
      accident: 'Não, o aparelho nunca caiu nem nada.',
      devices: 'O celular está normal. Só o computador está esquisito.',
      popups: 'Sim! Aparecem propagandas e um aviso pedindo pagamento para eu recuperar meus arquivos.',
      files: 'Minhas fotos e documentos sumiram ou ficaram com um nome esquisito.',
      model: 'Não sei dizer o modelo, mas é um notebook.',
    }),
  },
  wifi: {
    dept: 'network',
    intros: [
      'O Wi-Fi não conecta de jeito nenhum.',
      'Minha internet parou de funcionar no notebook e eu não consigo abrir nada.',
      'Aparece um aviso amarelo de "sem acesso à internet" e não carrega página nenhuma.',
    ],
    clues: (p) => ({
      when: 'Parou ontem à noite, depois que a energia caiu aqui em casa.',
      power: 'Liga normal e o sistema abre numa boa.',
      restart: 'Reiniciei e nada mudou.',
      accident: 'Não, está inteiro, nunca caiu.',
      devices: p.cause === 'ip'
        ? 'O celular conecta normal. Só esse computador não pega.'
        : 'Nenhum aparelho conecta, e a luz do roteador está piscando vermelha.',
      popups: 'Só aparece o aviso amarelo de "sem acesso à internet".',
      files: 'Meus arquivos estão todos aqui.',
      model: 'É um notebook, não sei o modelo exato.',
    }),
  },
};
const FALLBACK = [
  'Hmm, não sei explicar direito, sou leigo nisso.',
  'Não entendi bem a pergunta... pode perguntar de outro jeito?',
  'Isso eu não sei dizer, desculpa!',
];
// Palavras-chave => tópico (ordem importa: tópicos mais específicos primeiro)
const KEYWORDS = [
  ['accident', ['acidente', 'cair', 'caiu', 'queda', 'bateu', 'molhou', 'agua', 'derram']],
  ['devices', ['outro', 'aparelho', 'celular', 'telefone']],
  ['popups', ['janela', 'mensagem', 'aviso', 'estranh', 'propaganda', 'erro']],
  ['files', ['arquivo', 'pasta', 'foto', 'documento', 'sumiu']],
  ['restart', ['reinici', 'reset']],
  ['when', ['quando', 'comec', 'desde']],
  ['model', ['modelo', 'polegada', 'tamanho', 'marca']],
  ['power', ['liga', 'acende', 'boot', 'funciona', 'imagem', 'tela', 'video']],
];
const norm = (s) => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

// ============================================================================
// 2) ESTADO
// ============================================================================
/**
 * Player : { sid, socket, name, role, custom, x,y,z,ry, carry:itemId|null, inputs[], ack,
 *            ui:stationId|null, chatClient:clientId|null, spawnIdx, joinedAt }
 * Client : { id, name, look, problem, params, clues, chat[{from,text}], status:'waiting'|'inService',
 *            claimedBy:sid|null }
 * Item(PC): { id, os, clientId, customer, problem, params, actualDept, dept(encaminhado),
 *             summary, model, misroutes, mistakes, repaired }
 * itemCode: 0 nada | 1 Hardware | 2 Software | 3 Redes | 4 reparado
 * Estações: table {slots[4]} | bench {item, phase 0 vazio/1 colocado/2 em simulação/3 concluído,
 *           inspected, mismatch, sim}
 */
const players = new Map();
const clients = new Map();
const items = new Map();
const sstate = new Map();
let waitList = [];
let nextClientId = 1, nextItemId = 1, nextSid = 1, osCounter = 0, roleCursor = 0;
let worldDirty = true, lastWorldSent = 0;
const game = { score: 0, delivered: 0, routed: 0, routedOk: 0, nextClientAt: 0 };

function resetStations() {
  sstate.clear();
  for (const s of S.STATIONS) {
    if (s.type === 'table') sstate.set(s.id, { slots: new Array(s.slots).fill(null) });
    else if (s.type === 'bench') sstate.set(s.id, { item: null, phase: 0, inspected: false, mismatch: false, sim: null });
    else sstate.set(s.id, {});
  }
}
function resetGame() {
  clients.clear(); items.clear(); waitList = []; resetStations();
  for (const p of players.values()) { p.carry = null; p.ui = null; p.chatClient = null; }
  Object.assign(game, { score: 0, delivered: 0, routed: 0, routedOk: 0, nextClientAt: Date.now() + CFG.FIRST_CLIENT });
  worldDirty = true;
}
resetGame();

// ============================================================================
// 3) HELPERS
// ============================================================================
const rnd = (a) => a[Math.floor(Math.random() * a.length)];
const shuffle = (a) => a.map((v) => [Math.random(), v]).sort((x, y) => x[0] - y[0]).map((x) => x[1]);
const stationById = (id) => S.STATIONS.find((s) => s.id === id);
const osLabel = (n) => 'OS-' + String(n).padStart(4, '0');
const label = (role) => S.ROLE_LABEL[role];
const deptIndex = (d) => S.DEPTS.indexOf(d);

function itemCode(it) { return !it ? 0 : it.repaired ? 4 : deptIndex(it.dept) + 1; }
function itemInfo(it) {
  return { id: it.id, os: osLabel(it.os), customer: it.customer, summary: it.summary, model: it.model,
    dept: it.dept, repaired: it.repaired, mistakes: it.mistakes, misroutes: it.misroutes };
}
function roleCount(role) { let n = 0; for (const p of players.values()) if (p.role === role) n++; return n; }
function rosterPayload() {
  const slots = {};
  for (const r of S.ROLES) slots[r] = { used: roleCount(r), max: S.ROLE_LIMITS[r] };
  return { players: [...players.values()].map((p) => ({ sid: p.sid, name: p.name, role: p.role, custom: p.custom })), slots };
}
const broadcastRoster = () => io.emit('roster', rosterPayload());
const sys = (text) => io.emit('chat', { sys: true, text, t: Date.now() });
const deny = (p, code, msg) => p.socket.emit('denied', { code, msg });
const info = (p, msg) => p.socket.emit('info', { msg });
const playerBySid = (sid) => [...players.values()].find((p) => p.sid === sid) || null;
const sanitizeName = (n) => (String(n || '').replace(/[^\p{L}\p{N} _\-]/gu, '').trim().slice(0, 16)) || 'Colega' + Math.floor(Math.random() * 900 + 100);
const cleanText = (t, max) => String(t || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

/** Notificação DIRECIONADA: só os sockets da sala `role:<dept>` recebem. */
function notifyDept(dept, payload) { io.to('role:' + dept).emit('notify_task', payload); }

function tableFree(id) { return sstate.get(id).slots.indexOf(null); }
function pendingInTriage() {
  const out = { hardware: 0, software: 0, network: 0 };
  for (const id of sstate.get('T_in').slots) if (id) out[items.get(id).dept]++;
  return out;
}

// ============================================================================
// 4) MATCHMAKING DE FUNÇÕES (igual à v2, com a procura redefinida)
// ============================================================================
function demandByRole() {
  const d = { reception: waitList.length, hardware: 0, software: 0, network: 0 };
  for (const it of items.values()) { if (it.repaired) d.reception++; else d[it.dept]++; }
  return d;
}
function pickRole() {
  const counts = {};
  for (const r of S.ROLES) counts[r] = roleCount(r);
  const open = S.ROLES.filter((r) => counts[r] < S.ROLE_LIMITS[r]);
  const empty = open.filter((r) => counts[r] === 0);
  const pool = empty.length ? empty : open;
  const dem = demandByRole();
  const score = (r) => (empty.length ? dem[r] : (dem[r] + 0.5) / counts[r]);
  let best = -Infinity, tied = [];
  for (const r of pool) {
    const sc = score(r);
    if (sc > best + 1e-9) { best = sc; tied = [r]; } else if (Math.abs(sc - best) <= 1e-9) tied.push(r);
  }
  const n = S.ROLES.length;
  tied.sort((a, b) => ((S.ROLES.indexOf(a) - roleCursor + n) % n) - ((S.ROLES.indexOf(b) - roleCursor + n) % n));
  roleCursor = (S.ROLES.indexOf(tied[0]) + 1) % n;
  return tied[0];
}
function setRole(p, role) {
  if (p.role) p.socket.leave('role:' + p.role);
  p.role = role;
  p.socket.join('role:' + role);            // sala usada pelas notificações direcionadas
}
function rebalanceRoles() {
  for (const empty of S.ROLES) {
    if (roleCount(empty) > 0) continue;
    let donor = null;
    for (const r of S.ROLES) if (roleCount(r) > 1 && (!donor || roleCount(r) > roleCount(donor))) donor = r;
    if (!donor) return;
    const c = [...players.values()].filter((p) => p.role === donor && !p.carry).sort((a, b) => b.joinedAt - a.joinedAt);
    if (!c.length) continue;
    releaseClaim(c[0]); c[0].ui = null; c[0].socket.emit('close_station');
    setRole(c[0], empty);
    sys(`🔄 ${c[0].name} foi reatribuído(a) para ${label(empty)} para cobrir a equipa.`);
  }
}

// ============================================================================
// 5) CLIENTES NPC E CHAT
// ============================================================================
function randomLook() {
  const C = S.CUSTOMIZATION, k = (o) => rnd(Object.keys(o));
  return S.sanitizeCustom({ base: rnd(C.base), shirt: k(C.shirt), pants: k(C.pants), hair: k(C.hair), skin: k(C.skin), accessory: rnd(C.accessory) });
}

function addClient(now) {
  const key = rnd(Object.keys(PROBLEMS));
  const pr = PROBLEMS[key];
  const params = { model: rnd(['14', '15.6', '17']), cause: rnd(['ip', 'router']) };
  const taken = new Set([...clients.values()].map((c) => c.name));
  const name = rnd(NAMES.filter((n) => !taken.has(n)).concat(NAMES.slice(0, 1)));
  const c = { id: nextClientId++, name, look: randomLook(), problem: key, params, clues: pr.clues(params),
    chat: [{ from: 'client', text: rnd(pr.intros) }], status: 'waiting', claimedBy: null };
  clients.set(c.id, c);
  waitList.push(c.id);
  worldDirty = true;
  io.to('role:reception').emit('client_arrived', { customer: c.name, waiting: waitList.length });   // só a Recepção
}

/** "IA" simples: interpreta o texto livre por palavras-chave e responde com a pista do problema. */
function npcReply(c, text) {
  const t = norm(text);
  for (const [topic, words] of KEYWORDS) {
    if (words.some((w) => t.includes(w))) return c.clues[topic] || rnd(FALLBACK);
  }
  if (/\b(ola|oi|bom dia|boa tarde|boa noite)\b/.test(t)) return 'Olá! Pode me ajudar, por favor?';
  return rnd(FALLBACK);
}

function releaseClaim(p) {
  if (!p.chatClient) return;
  const c = clients.get(p.chatClient);
  if (c && c.claimedBy === p.sid) c.claimedBy = null;
  p.chatClient = null;
  worldDirty = true;
}

// ============================================================================
// 6) SIMULAÇÕES DE BANCADA (máquinas de estados autoritativas)
// ============================================================================
const MAL_FILES = [
  ['fatura_banco.pdf.exe', 'Origem: anexo de e-mail de phishing. Tenta cifrar documentos.'],
  ['atualizacao_flash.bat', 'Comportamento: comunica com um servidor desconhecido.'],
  ['cripto_miner.dll', 'Comportamento: consome CPU em segundo plano para minerar moedas.'],
  ['senha_roubada.vbs', 'Comportamento: copia palavras-passe guardadas no navegador.'],
];
const OK_FILES = [
  ['driver_audio.sys', 'Assinado digitalmente pelo fabricante. Sem comportamento suspeito.'],
  ['updater_oficial.exe', 'Assinado digitalmente. Atualizador legítimo do sistema.'],
  ['backup_agendado.bat', 'Script criado pelo próprio utilizador. Sem comunicação externa.'],
];

function initSim(it) {
  switch (it.problem) {
    case 'screen':
      return { type: 'screen', screws: [0, 0, 0, 0], removed: false, installed: null, connected: false };
    case 'malware': {
      const mal = shuffle(MAL_FILES).slice(0, 3).map(([name, note]) => ({ name, note, mal: true, risk: 'Alto' }));
      const ok = shuffle(OK_FILES).slice(0, 2).map(([name, note]) => ({ name, note, mal: false, risk: 'Médio' }));
      const files = shuffle(mal.concat(ok)).map((f, i) => ({ id: 'f' + (i + 1), q: false, ...f }));
      return { type: 'malware', phase: 'desktop', popups: 3, scanEnds: 0, files };
    }
    case 'wifi':
      return { type: 'wifi', cause: it.params.cause, ipFixed: false, routerFixed: false, log: ['Pronto. Usa as ferramentas para diagnosticar.'] };
  }
  return null;
}

const wifiFixed = (s) => (s.cause === 'ip' ? s.ipFixed : s.routerFixed);
const wifiLog = (s, line) => { s.log.push(line); if (s.log.length > 10) s.log.shift(); };

/** Cada simulador devolve { ok, msg?, mistake?, done? }. `msg` com ok=false vira aviso ao jogador. */
const SIMS = {
  screen(sim, it, act, arg) {
    switch (act) {
      case 'unscrew': {
        const i = Number(arg);
        if (!Number.isInteger(i) || i < 0 || i > 3) return { ok: false, msg: 'Parafuso inválido.' };
        if (sim.removed) return { ok: false, msg: 'A tela já foi retirada.' };
        if (sim.screws[i]) return { ok: false, msg: 'Esse parafuso já foi retirado.' };
        sim.screws[i] = 1; return { ok: true };
      }
      case 'remove':
        if (sim.removed) return { ok: false, msg: 'A tela antiga já saiu.' };
        if (!sim.screws.every(Boolean)) return { ok: false, msg: 'Ainda há parafusos a prender a tela.' };
        sim.removed = true; return { ok: true };
      case 'choose':
        if (!sim.removed) return { ok: false, msg: 'Remove a tela antiga primeiro.' };
        if (sim.installed) return { ok: false, msg: 'Já há uma tela instalada.' };
        if (!S.SCREEN_OPTIONS.some((o) => o.key === arg)) return { ok: false, msg: 'Peça inexistente.' };
        if (arg !== it.params.model) return { ok: false, mistake: true, msg: `Essa tela não encaixa neste ${it.model}.` };
        sim.installed = arg; return { ok: true };
      case 'connect':
        if (!sim.installed) return { ok: false, msg: 'Instala a nova tela primeiro.' };
        sim.connected = true; return { ok: true };
      case 'test':
        if (!sim.connected) return { ok: false, msg: 'Liga o cabo de vídeo antes de testar.' };
        return { ok: true, done: true };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  malware(sim, it, act, arg, now) {
    switch (act) {
      case 'close_popup': sim.popups = Math.max(0, sim.popups - 1); return { ok: true };
      case 'open_av':
        if (sim.phase !== 'desktop') return { ok: false, msg: 'O antivírus já está aberto.' };
        sim.phase = 'av'; return { ok: true };
      case 'run_scan':
        if (sim.phase !== 'av') return { ok: false, msg: 'Abre o antivírus primeiro.' };
        sim.phase = 'scanning'; sim.scanEnds = now + CFG.SCAN_MS; return { ok: true };
      case 'quarantine': {
        if (sim.phase !== 'results') return { ok: false, msg: 'Aguarda o fim da verificação.' };
        const f = sim.files.find((x) => x.id === arg);
        if (!f) return { ok: false, msg: 'Ficheiro inexistente.' };
        if (f.q) return { ok: false, msg: 'Já está em quarentena.' };
        if (!f.mal) return { ok: false, mistake: true, msg: `«${f.name}» é um ficheiro legítimo! Quarentena cancelada.` };
        f.q = true; return { ok: true };
      }
      case 'finish':
        if (sim.phase !== 'results') return { ok: false, msg: 'Executa a verificação primeiro.' };
        if (!sim.files.every((f) => !f.mal || f.q)) return { ok: false, msg: 'Ainda há ameaças ativas no sistema.' };
        return { ok: true, done: true };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },

  wifi(sim, it, act, arg) {
    switch (act) {
      case 'ipconfig':
        wifiLog(sim, '> ipconfig');
        wifiLog(sim, `  IPv4: ${wifiIp(sim)}   Gateway: 192.168.1.1`);
        return { ok: true };
      case 'ping': {
        const t = arg === 'internet' ? 'internet' : 'gateway';
        wifiLog(sim, `> ping ${t === 'internet' ? '8.8.8.8' : '192.168.1.1'}`);
        let okp;
        if (sim.cause === 'ip' && !sim.ipFixed) okp = false;                 // sem IP válido: nada responde
        else if (sim.cause === 'router' && !sim.routerFixed) okp = t === 'gateway';   // LAN ok, WAN em baixo
        else okp = true;
        wifiLog(sim, okp ? '  Resposta recebida (4/4).' : (sim.cause === 'ip' ? '  Destino inacessível.' : '  Tempo esgotado.'));
        return { ok: true };
      }
      case 'renew_ip':
        if (sim.cause === 'ip' && !sim.ipFixed) { sim.ipFixed = true; wifiLog(sim, '> DHCP: novo IP 192.168.1.42 atribuído.'); }
        else wifiLog(sim, '> DHCP: IP renovado (sem alterações).');
        return { ok: true };
      case 'restart_router':
        if (sim.cause === 'router' && !sim.routerFixed) { sim.routerFixed = true; wifiLog(sim, '> Roteador reiniciado. WAN: online.'); return { ok: true }; }
        wifiLog(sim, '> Roteador reiniciado (estava saudável).');
        return { ok: false, mistake: true, msg: 'O roteador estava saudável. Reiniciá-lo derrubou a rede de todos por um instante.' };
      case 'test':
        if (wifiFixed(sim)) return { ok: true, done: true };
        wifiLog(sim, '> Teste de ligação: sem acesso à internet.');
        return { ok: false, msg: 'Ainda sem acesso à internet.' };
    }
    return { ok: false, msg: 'Ação desconhecida.' };
  },
};
const wifiIp = (s) => (s.cause === 'ip' && !s.ipFixed ? '169.254.23.17 (autoconfiguração)' : '192.168.1.42');

/** Vista da simulação para o cliente: NUNCA inclui segredos (qual ficheiro é malicioso, causa da rede). */
function simView(sim, now) {
  if (!sim) return null;
  switch (sim.type) {
    case 'screen':
      return { type: 'screen', screws: sim.screws, removed: sim.removed, installed: sim.installed,
        connected: sim.connected, options: S.SCREEN_OPTIONS };
    case 'malware':
      return { type: 'malware', phase: sim.phase, popups: sim.popups, total: CFG.SCAN_MS,
        msLeft: sim.phase === 'scanning' ? Math.max(0, sim.scanEnds - now) : 0,
        files: sim.phase === 'results' ? sim.files.map((f) => ({ id: f.id, name: f.name, risk: f.risk, note: f.note, q: f.q })) : [] };
    case 'wifi':
      return { type: 'wifi', ip: wifiIp(sim), gateway: '192.168.1.1',
        adapter: wifiFixed(sim) ? 'Conectado' : 'Sem acesso à internet',
        wan: sim.cause === 'router' && !sim.routerFixed ? 'Sem sinal' : 'Online', log: sim.log };
  }
  return null;
}

// ============================================================================
// 7) VISTAS DE ESTAÇÃO (open_station)
// ============================================================================
function viewFor(p, s) {
  const st = sstate.get(s.id), now = Date.now();
  const base = { id: s.id, type: s.type, label: s.label, role: s.role || null };
  switch (s.type) {
    case 'counter': {
      const list = waitList.map((id) => {
        const c = clients.get(id), other = c.claimedBy && c.claimedBy !== p.sid ? playerBySid(c.claimedBy) : null;
        return { id, name: c.name, busyWith: other ? other.name : null };
      });
      const c = p.chatClient ? clients.get(p.chatClient) : null;
      const active = c && c.status === 'waiting'
        ? { id: c.id, name: c.name, chat: c.chat, os: osLabel(osCounter + 1) } : null;
      return { ...base, list, active, depts: S.DEPTS.map((d) => ({ key: d, label: label(d) })), chips: S.QUICK_QUESTIONS };
    }
    case 'bench': {
      const it = st.item ? items.get(st.item) : null;
      return { ...base, dept: s.role, phase: st.phase, inspected: st.inspected, mismatch: st.mismatch,
        actualDept: st.mismatch && it ? it.actualDept : null, actualLabel: st.mismatch && it ? label(it.actualDept) : null,
        item: it ? itemInfo(it) : null, sim: st.phase >= 2 ? simView(st.sim, now) : null };
    }
    case 'delivery': {
      const it = p.carry ? items.get(p.carry) : null;
      return { ...base, item: it ? itemInfo(it) : null };
    }
  }
  return base;
}
const sendView = (p, s) => { p.ui = s.id; p.socket.emit('open_station', viewFor(p, s)); };
function closeView(p) { p.ui = null; releaseClaim(p); p.socket.emit('close_station'); }

function stationFor(p, id, types) {
  const s = typeof id === 'string' ? stationById(id) : null;
  if (!s || !types.includes(s.type)) { deny(p, 'bad_station', 'Estação inválida.'); return null; }
  if (S.distToRect(p.x, p.z, s) > S.INTERACT_RANGE + 0.6) { deny(p, 'too_far', 'Afastaste-te demasiado da estação.'); closeView(p); return null; }
  if (s.role && s.role !== p.role) { deny(p, 'role_not_allowed', `${label(p.role)} não pode usar «${s.label}». Só ${label(s.role)}.`); return null; }
  return s;
}
function nearestStation(p) {
  let best = null, bd = Infinity;
  for (const s of S.STATIONS) { const d = S.distToRect(p.x, p.z, s); if (d <= S.INTERACT_RANGE && d < bd) { bd = d; best = s; } }
  return best;
}

// ============================================================================
// 8) INTERAÇÃO "E"
// ============================================================================
function handleInteract(p) {
  const s = nearestStation(p);
  if (!s) return deny(p, 'no_station', 'Não há nenhuma estação ao alcance.');
  if (s.role && s.role !== p.role) {
    return deny(p, 'role_not_allowed', `${label(p.role)} não pode usar «${s.label}». Só ${label(s.role)}.`);
  }
  const st = sstate.get(s.id);

  switch (s.type) {
    case 'counter': return sendView(p, s);

    case 'table': {
      if (s.kind === 'in') {                               // MESA DE TRIAGEM
        if (p.role === 'reception') return deny(p, 'not_tech', 'A Recepção deixa a OS no sistema; só técnicos recolhem máquinas aqui.');
        if (p.carry) return deny(p, 'hands_full', 'Já estás a carregar uma máquina.');
        const idx = st.slots.findIndex((id) => id && items.get(id).dept === p.role);
        if (idx < 0) return deny(p, 'nothing_for_you', `Nenhuma máquina encaminhada para ${label(p.role)}.`);
        p.carry = st.slots[idx]; st.slots[idx] = null;
      } else {                                             // MESA DE SAÍDA
        if (p.carry) {
          if (p.role === 'reception') return deny(p, 'hands_full', 'Já estás a carregar um PC.');
          if (!items.get(p.carry).repaired) return deny(p, 'not_repaired', 'Este PC ainda não foi reparado.');
          const idx = tableFree(s.id);
          if (idx < 0) return deny(p, 'table_full', 'A mesa de saída está cheia.');
          st.slots[idx] = p.carry; p.carry = null;
        } else {
          if (p.role !== 'reception') return deny(p, 'only_reception', 'Só a Recepção recolhe PCs reparados aqui.');
          const idx = st.slots.findIndex((x) => x !== null);
          if (idx < 0) return deny(p, 'table_empty', 'Não há PCs prontos para entrega.');
          p.carry = st.slots[idx]; st.slots[idx] = null;
        }
      }
      worldDirty = true; return;
    }

    case 'bench': {
      if (p.carry) {
        const it = items.get(p.carry);
        if (st.phase !== 0) return deny(p, 'bench_busy', 'A bancada já está ocupada.');
        if (it.repaired) return deny(p, 'already_done', 'Este PC já está reparado. Leva-o à Mesa de Saída.');
        if (it.dept !== s.role) return deny(p, 'wrong_dept', `Esta máquina foi encaminhada para ${label(it.dept)}.`);
        Object.assign(st, { item: p.carry, phase: 1, inspected: false, mismatch: false, sim: null });
        p.carry = null; worldDirty = true;
        return sendView(p, s);
      }
      if (st.phase === 0) return deny(p, 'bench_empty', 'Traz uma máquina da Mesa de Triagem.');
      return sendView(p, s);
    }

    case 'delivery': {
      if (!p.carry) return deny(p, 'no_item', 'Traz um PC reparado da Mesa de Saída.');
      return sendView(p, s);
    }
  }
}

// ============================================================================
// 9) AÇÕES — RECEPÇÃO
// ============================================================================
function actChatOpen(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  const c = clients.get(d.clientId);
  if (!c || c.status !== 'waiting') { deny(p, 'gone', 'Esse cliente já foi atendido.'); return sendView(p, s); }
  if (c.claimedBy && c.claimedBy !== p.sid && playerBySid(c.claimedBy)) {
    deny(p, 'busy', 'Outro colega já está a atender este cliente.'); return sendView(p, s);
  }
  releaseClaim(p);
  c.claimedBy = p.sid; p.chatClient = c.id; worldDirty = true;
  sendView(p, s);
}
function actChatRelease(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  releaseClaim(p); sendView(p, s);
}
function actChatSay(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  const c = p.chatClient ? clients.get(p.chatClient) : null;
  if (!c || c.status !== 'waiting') return deny(p, 'no_chat', 'Abre primeiro a conversa com um cliente.');
  const text = cleanText(d.text, 120);
  if (!text) return;
  c.chat.push({ from: 'rec', text });
  const reply = npcReply(c, text);
  sendView(p, s);
  setTimeout(() => {                                       // o NPC "pensa" um instante
    if (c.status !== 'waiting') return;
    c.chat.push({ from: 'client', text: reply });
    if (c.chat.length > 40) c.chat.splice(0, c.chat.length - 40);
    if (p.ui === 'counter' && p.chatClient === c.id) sendView(p, s);
  }, 600 + Math.random() * 500);
}

/** Recebe a OS: valida, cria o PC (ligado à OS), coloca-o na triagem e notifica SÓ o departamento escolhido. */
function actOsSubmit(p, d) {
  const s = stationFor(p, d.station, ['counter']); if (!s) return;
  const c = p.chatClient ? clients.get(p.chatClient) : null;
  if (!c || c.status !== 'waiting') return deny(p, 'no_chat', 'Abre primeiro a conversa com um cliente.');
  const summary = cleanText(d.summary, 160);
  if (summary.length < 5) return deny(p, 'bad_summary', 'Descreve o problema na OS (mínimo 5 caracteres).');
  if (!S.DEPTS.includes(d.dept)) return deny(p, 'bad_dept', 'Escolhe o departamento de destino.');
  const slot = tableFree('T_in');
  if (slot < 0) return deny(p, 'triage_full', 'A Mesa de Triagem está cheia. Aguarda os técnicos recolherem máquinas.');

  const it = { id: nextItemId++, os: ++osCounter, clientId: c.id, customer: c.name, problem: c.problem, params: c.params,
    actualDept: PROBLEMS[c.problem].dept, dept: d.dept, summary, model: `Notebook ${c.params.model}″`,
    misroutes: 0, mistakes: 0, repaired: false };
  items.set(it.id, it);
  sstate.get('T_in').slots[slot] = it.id;
  c.status = 'inService'; c.claimedBy = null; p.chatClient = null;
  waitList = waitList.filter((id) => id !== c.id);

  notifyDept(d.dept, { os: osLabel(it.os), customer: c.name, dept: d.dept,
    text: 'Nova máquina aguardando reparo na bancada de triagem', pending: pendingInTriage()[d.dept] });
  info(p, `${osLabel(it.os)} enviada para ${label(d.dept)}.`);
  worldDirty = true;
  sendView(p, s);                                           // volta à lista de clientes
}

function actDeliver(p, d) {
  const s = stationFor(p, d.station, ['delivery']); if (!s) return;
  if (!p.carry) return deny(p, 'no_item', 'Não estás a carregar nenhum PC.');
  const it = items.get(p.carry);
  if (!it.repaired) return deny(p, 'not_ready', 'Este PC ainda não está reparado.');
  const stars = Math.max(1, 5 - Math.floor(it.mistakes / 2) - it.misroutes);
  game.score += stars * CFG.SCORE_PER_STAR; game.delivered++;
  items.delete(it.id); clients.delete(it.clientId); p.carry = null;
  io.to('role:reception').emit('delivered', { customer: it.customer, stars, text: THANKS[stars - 1], os: osLabel(it.os) });
  worldDirty = true;
  closeView(p);
}

// ============================================================================
// 10) AÇÕES — BANCADAS
// ============================================================================
function actInspect(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (st.phase !== 1 || st.inspected) return deny(p, 'bad_phase', 'Nada para inspecionar.');
  const it = items.get(st.item);
  st.inspected = true; game.routed++;
  if (it.actualDept === s.role) { game.routedOk++; st.mismatch = false; st.sim = initSim(it); st.phase = 2; }
  else st.mismatch = true;                                  // triagem errada: só resta reencaminhar
  worldDirty = true; sendView(p, s);
}

function actReroute(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (st.phase !== 1 || !st.mismatch) return deny(p, 'bad_phase', 'Só podes reencaminhar após uma inspeção que revele triagem errada.');
  if (!S.DEPTS.includes(d.dept) || d.dept === s.role) return deny(p, 'bad_dept', 'Departamento inválido.');
  const slot = tableFree('T_in');
  if (slot < 0) return deny(p, 'triage_full', 'A Mesa de Triagem está cheia.');
  const it = items.get(st.item);
  it.dept = d.dept; it.misroutes++; game.score -= CFG.PEN_MISROUTE;
  sstate.get('T_in').slots[slot] = it.id;
  Object.assign(st, { item: null, phase: 0, inspected: false, mismatch: false, sim: null });
  notifyDept(d.dept, { os: osLabel(it.os), customer: it.customer, dept: d.dept,
    text: 'Nova máquina aguardando reparo na bancada de triagem', pending: pendingInTriage()[d.dept] });
  io.to('role:reception').emit('triage_feedback', { os: osLabel(it.os), from: label(s.role), to: label(d.dept),
    text: `${osLabel(it.os)} foi reencaminhada de ${label(s.role)} para ${label(d.dept)}: a triagem inicial estava incorreta.` });
  worldDirty = true; closeView(p);
}

function actSim(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (st.phase !== 2 || !st.sim) return deny(p, 'bad_phase', 'Inspeciona o equipamento primeiro.');
  const it = items.get(st.item);
  const fn = SIMS[st.sim.type];
  const r = fn(st.sim, it, String(d.act || ''), d.arg, Date.now());
  if (r.mistake) { it.mistakes++; game.score -= CFG.PEN_MISTAKE; worldDirty = true; }
  if (!r.ok && r.msg) deny(p, 'sim', r.msg);
  if (r.done) { st.phase = 3; it.repaired = true; worldDirty = true; }
  sendView(p, s);
}

function actBenchCollect(p, d) {
  const s = stationFor(p, d.station, ['bench']); if (!s) return;
  const st = sstate.get(s.id);
  if (p.carry) return deny(p, 'hands_full', 'Já estás a carregar uma máquina.');
  if (st.phase === 0) return deny(p, 'bench_empty', 'A bancada está vazia.');
  if (st.phase === 2) return deny(p, 'in_progress', 'Termina o reparo antes de retirar a máquina.');
  if (st.phase === 1 && st.inspected) return deny(p, 'must_reroute', 'Esta máquina precisa de ser reencaminhada.');
  p.carry = st.item;
  Object.assign(st, { item: null, phase: 0, inspected: false, mismatch: false, sim: null });
  worldDirty = true; closeView(p);
}

// ============================================================================
// 11) LÓGICA PERIÓDICA (10 Hz)
// ============================================================================
function updateGame(now) {
  if (players.size === 0) return;
  if (now >= game.nextClientAt) {
    game.nextClientAt = now + CFG.CLIENT_EVERY;
    if (waitList.length < CFG.MAX_WAIT) addClient(now);
  }
  for (const s of S.STATIONS) {                             // fim da verificação do antivírus
    if (s.type !== 'bench') continue;
    const st = sstate.get(s.id);
    if (st.phase === 2 && st.sim && st.sim.type === 'malware' && st.sim.phase === 'scanning' && now >= st.sim.scanEnds) {
      st.sim.phase = 'results'; worldDirty = true;
    }
  }
}

function refreshOpenViews() {
  for (const p of players.values()) {
    if (!p.ui) continue;
    const s = stationById(p.ui);
    if (!s || (s.role && s.role !== p.role) || S.distToRect(p.x, p.z, s) > S.INTERACT_RANGE + 0.6) { closeView(p); continue; }
    if (s.type === 'delivery' && !p.carry) { closeView(p); continue; }
    p.socket.emit('open_station', viewFor(p, s));
  }
}

function worldPayload() {
  const st = {};
  for (const s of S.STATIONS) {
    const d = sstate.get(s.id);
    if (s.type === 'table') st[s.id] = d.slots.map((id) => (id ? itemCode(items.get(id)) : 0));
    else if (s.type === 'bench') st[s.id] = [d.item ? itemCode(items.get(d.item)) : 0, d.phase];
  }
  return { st, q: waitList.length, wip: items.size, dv: game.delivered, score: game.score,
    acc: game.routed ? Math.round((100 * game.routedOk) / game.routed) : null,
    tri: pendingInTriage(),
    cl: waitList.map((id) => { const c = clients.get(id); return { id, name: c.name, look: c.look, serving: !!c.claimedBy }; }) };
}

// ============================================================================
// 12) LOOP PRINCIPAL (passo fixo 60 Hz)
// ============================================================================
const DT_MS = 1000 / S.TICK_RATE;
let acc = 0, prev = Date.now(), tickCount = 0;

function tick(now) {
  tickCount++;
  for (const p of players.values()) {
    const inp = p.inputs.shift();
    if (inp) { S.stepPlayer(p, inp, S.DT); p.ack = inp.seq; }
  }
  if (tickCount % 3 === 0) {
    const arr = [];
    for (const p of players.values()) {
      arr.push([p.sid, +p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2), +p.ry.toFixed(2),
        itemCode(p.carry ? items.get(p.carry) : null), p.ack]);
    }
    io.volatile.emit('snap', { t: now, p: arr });
    if (worldDirty || now - lastWorldSent > 1000) { io.emit('world', worldPayload()); worldDirty = false; lastWorldSent = now; }
  }
  if (tickCount % 6 === 0) updateGame(now);
  if (tickCount % 30 === 0) refreshOpenViews();
}
setInterval(() => {
  const now = Date.now();
  acc += now - prev; prev = now;
  if (acc > 250) acc = 250;
  while (acc >= DT_MS) { acc -= DT_MS; tick(Date.now()); }
}, 4);

// ============================================================================
// 13) SOCKET.IO
// ============================================================================
function rate(p, key, ms) { const now = Date.now(); if (now - (p[key] || 0) < ms) return false; p[key] = now; return true; }

/** Devolve a máquina à mesa certa se o dono sair (para não perder trabalho). */
function returnItem(itemId) {
  const it = items.get(itemId);
  if (!it) return;
  const table = it.repaired ? 'T_out' : 'T_in';
  const idx = tableFree(table);
  if (idx < 0) { items.delete(itemId); clients.delete(it.clientId); return; }
  sstate.get(table).slots[idx] = itemId;
}

io.on('connection', (socket) => {
  socket.emit('roster', rosterPayload());

  socket.on('join', (data, cb) => {
    if (typeof cb !== 'function') cb = () => {};
    if (players.has(socket.id)) return cb({ ok: false, error: 'Já estás na sala.' });
    if (players.size >= S.MAX_PLAYERS) return cb({ ok: false, error: 'Sala cheia (14/14).' });

    const used = new Set([...players.values()].map((q) => q.spawnIdx));
    let spawnIdx = 0; while (used.has(spawnIdx)) spawnIdx++;
    const sp = S.spawnPoint(spawnIdx);
    const role = pickRole();
    const p = { sid: nextSid++, socket, name: sanitizeName(data && data.name), role: null, custom: S.sanitizeCustom(data && data.custom),
      x: sp.x, y: sp.y, z: sp.z, ry: 0, carry: null, inputs: [], lastSeqIn: 0, ack: 0, ui: null, chatClient: null,
      spawnIdx, joinedAt: Date.now() };
    setRole(p, role);
    players.set(socket.id, p);

    cb({ ok: true, you: { sid: p.sid, name: p.name, role, custom: p.custom, x: p.x, y: p.y, z: p.z }, world: worldPayload() });
    broadcastRoster();
    sys(`👋 ${p.name} entrou na equipa de ${label(role)}.`);
    worldDirty = true;
  });

  socket.on('customize', (c) => {
    const p = players.get(socket.id);
    if (!p || !rate(p, 'tCustom', 400)) return;
    p.custom = S.sanitizeCustom(c);
    broadcastRoster();
  });

  socket.on('inputs', (arr) => {
    const p = players.get(socket.id);
    if (!p || !Array.isArray(arr)) return;
    for (let i = 0; i < Math.min(arr.length, 10); i++) {
      const inp = arr[i];
      if (!inp || !Number.isInteger(inp.seq) || inp.seq <= p.lastSeqIn) continue;
      if (p.inputs.length >= 15) break;
      p.lastSeqIn = inp.seq;
      p.inputs.push({ seq: inp.seq, dx: +inp.dx || 0, dz: +inp.dz || 0 });
    }
  });

  const action = (event, fn, ms = 120) => socket.on(event, (data) => {
    const p = players.get(socket.id);
    if (!p || !rate(p, 't_' + event, ms)) return;
    fn(p, data && typeof data === 'object' ? data : {});
  });
  action('interact', (p) => handleInteract(p), 150);
  action('chat_open', actChatOpen);
  action('chat_release', actChatRelease);
  action('chat_say', actChatSay, 500);
  action('os_submit', actOsSubmit, 300);
  action('deliver', actDeliver);
  action('inspect', actInspect);
  action('reroute', actReroute);
  action('sim', actSim, 100);
  action('bench_collect', actBenchCollect);
  socket.on('ui_close', () => { const p = players.get(socket.id); if (p) { p.ui = null; releaseClaim(p); } });

  socket.on('chat', (text) => {
    const p = players.get(socket.id);
    if (!p || !rate(p, 'tChat', 500)) return;
    const clean = cleanText(text, 200);
    if (clean) io.emit('chat', { name: p.name, role: p.role, text: clean, t: Date.now() });
  });
  socket.on('emote', (e) => {
    const p = players.get(socket.id);
    if (!p || !EMOTES.includes(e) || !rate(p, 'tEmote', 800)) return;
    io.emit('emote', { sid: p.sid, e });
  });

  socket.on('disconnect', () => {
    const p = players.get(socket.id);
    if (!p) return;
    releaseClaim(p);
    if (p.carry) returnItem(p.carry);
    players.delete(socket.id);
    rebalanceRoles();
    broadcastRoster();
    sys(`🚪 ${p.name} saiu.`);
    if (players.size === 0) resetGame();
    worldDirty = true;
  });
});

server.listen(PORT, () => console.log(`TI Company Simulator em http://localhost:${PORT}`));
