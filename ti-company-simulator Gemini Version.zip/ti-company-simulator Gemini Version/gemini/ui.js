/**
 * public/js/ui.js (v3) — Camada de UI (DOM puro). Não conhece Three.js nem Socket.io.
 * Fala com o jogo por callbacks `UI.on.*` e métodos públicos `UI.*`.
 * Todas as strings vindas da rede entram no DOM via textContent (anti-XSS).
 *
 * Modais abertos pelo servidor (`open_station`):
 *   counter  -> lista de clientes + chat + formulário da Ordem de Serviço (Recepção)
 *   bench    -> inspeção + simulação 2D conforme o problema (tela / antivírus / rede)
 *   delivery -> devolução do PC ao cliente
 */
(() => {
  'use strict';
  const S = window.Shared;
  const $ = (sel) => document.querySelector(sel);

  const EMOTES = ['👍', '😅', '🔥', '🆘', '☕'];
  const UI = { on: {}, EMOTES, typing: false, isTyping() { return UI.typing; } };

  function el(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (v === true) e.setAttribute(k, '');
      else if (v !== false && v != null) e.setAttribute(k, v);
    }
    for (const kid of kids.flat()) if (kid != null) e.append(kid);
    return e;
  }
  const hex = (n) => '#' + n.toString(16).padStart(6, '0');
  const rnd = (a) => a[Math.floor(Math.random() * a.length)];
  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (_) { return null; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) { /* modo privado */ } },
  };
  UI.loadSaved = () => ({ name: store.get('tic.name') || '', custom: S.sanitizeCustom(store.get('tic.custom')) });

  document.addEventListener('focusin', (e) => { UI.typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName); });
  document.addEventListener('focusout', () => { UI.typing = false; });

  let joined = false, mySid = null, myRole = null;
  const act = (event, payload) => UI.on.action && UI.on.action(event, payload);

  // ==========================================================================
  // ENTRADA / JOGADORES / NAVEGAÇÃO
  // ==========================================================================
  $('#join-name').value = UI.loadSaved().name;
  $('#join-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = $('#join-name').value.trim();
    if (!name) return;
    $('#join-error').textContent = '';
    store.set('tic.name', name);
    UI.on.join && UI.on.join(name, UI.loadSaved().custom);
  });
  UI.joinError = (m) => { $('#join-error').textContent = m; };
  UI.hideJoin = () => {
    joined = true;
    $('#join').hidden = true;
    for (const id of ['#hud', '#nav-panel', '#chat', '#top-right', '#fab']) $(id).hidden = false;
  };

  UI.updateRoster = (r, sid) => {
    mySid = sid != null ? sid : mySid;
    $('#online-count').textContent = `${r.players.length}/${S.MAX_PLAYERS}`;
    $('#join-count').textContent = `${r.players.length}/${S.MAX_PLAYERS} pessoas no escritório`;
    const ul = $('#players-list');
    ul.innerHTML = '';
    for (const p of r.players) {
      ul.append(el('li', { class: p.sid === mySid ? 'me' : '' },
        el('i', { class: 'dot', title: 'Online' }),
        el('span', { text: p.name + (p.sid === mySid ? ' (tu)' : '') }),
        el('span', { class: 'role-tag', 'data-role': p.role, text: S.ROLE_LABEL[p.role] })));
    }
  };
  UI.setMe = (name, role) => { myRole = role; $('#my-role-line').textContent = 'A tua função: ' + S.ROLE_LABEL[role]; };

  for (const z of S.ZONES) {
    $('#zone-list').append(el('li', {},
      el('button', { type: 'button', onclick: () => UI.on.goto && UI.on.goto(z.id) },
        el('span', { class: 'ico', 'aria-hidden': 'true', text: z.icon }), z.label)));
  }

  // ==========================================================================
  // HUD / CHAT DA EQUIPA / BANNERS / TOASTS
  // ==========================================================================
  UI.setHud = (w, role) => {
    $('#hud-score').textContent = w.score;
    if (role === 'reception') { $('#hud-a-label').textContent = 'Clientes na fila'; $('#hud-a').textContent = w.q; }
    else { $('#hud-a-label').textContent = 'Na triagem'; $('#hud-a').textContent = (w.tri && w.tri[role]) || 0; }
    $('#hud-wip').textContent = w.wip;
    $('#hud-done').textContent = w.dv;
    $('#hud-acc').textContent = w.acc == null ? '—' : w.acc + '%';
  };

  const roleColor = { reception: '#3b82f6', hardware: '#d97706', software: '#7c3aed', network: '#0d9488' };
  UI.addChat = (m) => {
    const log = $('#chat-log');
    const row = el('div', { class: 'msg' + (m.sys ? ' sys' : '') });
    if (m.sys) row.textContent = m.text;
    else row.append(el('span', { class: 'who', text: m.name + ': ', style: `color:${roleColor[m.role] || 'inherit'}` }), el('span', { text: m.text }));
    log.append(row);
    while (log.children.length > 100) log.firstChild.remove();
    log.scrollTop = log.scrollHeight;
  };
  $('#chat-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const t = $('#chat-input').value.trim();
    if (t && UI.on.chat) UI.on.chat(t);
    $('#chat-input').value = '';
  });
  $('#chat-input').addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') e.target.blur(); });

  /** Banner flutuante no topo. `kind` só muda a cor/ícone. */
  UI.banner = ({ icon, title, sub, kind }) => {
    const slot = $('#banner-slot');
    while (slot.children.length >= 2) slot.firstChild.remove();
    const b = el('div', { class: 'banner' + (kind ? ' ' + kind : ''), role: 'status' },
      el('span', { 'aria-hidden': 'true', text: icon }),
      el('div', {}, title, sub ? el('br') : null, sub ? el('small', { text: sub }) : null));
    slot.append(b);
    setTimeout(() => { b.classList.add('out'); setTimeout(() => b.remove(), 360); }, 5000);
  };
  // Só a Recepção recebe este evento do servidor
  UI.showClientBanner = (customer, waiting) =>
    UI.banner({ icon: '🔔', title: 'Novo cliente aguardando na Recepção!', sub: `${customer} · na fila: ${waiting}` });
  // Só os técnicos do departamento escolhido recebem este evento do servidor
  UI.showTaskBanner = (d) =>
    UI.banner({ icon: '🛠️', kind: 'task', title: d.text, sub: `${d.os} · ${d.customer} · ${d.pending} na triagem` });

  UI.setPrompt = (text, locked) => {
    const p = $('#prompt');
    if (!text) { p.hidden = true; return; }
    p.hidden = false; p.textContent = text; p.classList.toggle('locked', !!locked);
  };
  UI.toast = (text, kind) => {
    const t = el('div', { class: 'toast' + (kind === 'info' ? ' info' : ''), text });
    $('#toasts').append(t);
    while ($('#toasts').children.length > 3) $('#toasts').firstChild.remove();
    setTimeout(() => t.remove(), 3600);
  };

  EMOTES.forEach((e, i) => $('#emote-bar').append(el('button', {
    class: 'fab', type: 'button', title: `Emote ${i + 1}`, text: e,
    onclick: () => { UI.on.emote && UI.on.emote(e); $('#emote-bar').hidden = true; },
  })));
  $('#fab-emote').addEventListener('click', () => { $('#emote-bar').hidden = !$('#emote-bar').hidden; });
  $('#fab-interact').addEventListener('click', () => UI.on.interact && UI.on.interact());
  $('#fab-voice').addEventListener('click', (ev) => {
    const b = ev.currentTarget, on = b.getAttribute('aria-pressed') !== 'true';
    b.setAttribute('aria-pressed', String(on));
    UI.on.voice && UI.on.voice(on);
  });
  $('#btn-exit').addEventListener('click', () => { if (confirm('Sair do escritório?')) UI.on.leave && UI.on.leave(); });

  // ==========================================================================
  // MODAL DE ESTAÇÃO — infraestrutura
  // ==========================================================================
  let cur = null;          // { view, sig, at }
  let raf = 0, lastStep = -1;

  UI.modalOpen = () => !$('#station-modal').hidden || !$('#character-modal').hidden;
  UI.openStationId = () => (cur ? cur.view.id : null);

  /** Assinatura da vista SEM campos de tempo: só reconstruímos o DOM quando o estado muda. */
  const sigOf = (v) => JSON.stringify(v, (k, val) => (k === 'msLeft' ? undefined : val));

  function ticketCard(it, hl) {
    return el('div', { class: 'ticket' + (hl ? ' hl' : '') },
      el('div', { class: 'ticket-top' }, el('b', { text: `${it.os} · ${it.customer}` }),
        el('span', { class: 'badge ' + it.dept, text: S.ROLE_LABEL[it.dept] })),
      el('p', { text: it.summary }),
      el('div', { class: 'badges' }, el('span', { class: 'badge', text: it.model }),
        it.mistakes ? el('span', { class: 'badge', text: `${it.mistakes} erro(s)` }) : null));
  }
  function timedBar(left, total, mode) {
    return el('div', { class: 'bar', 'data-left': left, 'data-total': total, 'data-mode': mode }, el('i'));
  }
  const btn = (text, cls, onclick, disabled) => el('button', { class: 'btn ' + cls, type: 'button', text, onclick, disabled: !!disabled });

  // ==========================================================================
  // RECEPÇÃO — lista de clientes, chat e Ordem de Serviço
  // ==========================================================================
  function buildCounter(v, body) {
    $('#sm-icon').textContent = '🛎️';
    $('#sm-sub').textContent = 'Descobre o problema com o cliente e abre a Ordem de Serviço.';
    if (!v.active) {
      body.append(el('div', { class: 'sec-title', text: `Clientes aguardando (${v.list.length})` }));
      if (!v.list.length) body.append(el('div', { class: 'empty', text: 'Ninguém na fila. Os clientes chegam ao longo do dia.' }));
      for (const c of v.list) {
        body.append(el('div', { class: 'ticket' },
          el('div', { class: 'ticket-top' }, el('b', { text: c.name }),
            btn(c.busyWith ? `Em atendimento (${c.busyWith})` : 'Atender', 'btn-primary',
              () => act('chat_open', { station: v.id, clientId: c.id }), !!c.busyWith))));
      }
      return;
    }
    const a = v.active;
    const bubbles = el('div', { class: 'bubbles', id: 'bubbles', role: 'log' },
      a.chat.map((m) => el('div', { class: 'bubble ' + (m.from === 'rec' ? 'me' : 'them'), text: m.text })));
    const say = (text) => { if (text.trim()) act('chat_say', { station: v.id, text }); };
    const sayInput = el('input', { type: 'text', maxlength: '120', 'data-keep': 'say', autocomplete: 'off', placeholder: 'Pergunte algo ao cliente…', 'aria-label': 'Mensagem ao cliente' });
    const sayForm = el('form', { class: 'say-form' }, sayInput, el('button', { class: 'btn btn-primary', type: 'submit', text: 'Enviar' }));
    sayForm.addEventListener('submit', (e) => { e.preventDefault(); say(sayInput.value); sayInput.value = ''; });
    sayInput.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') UI.closeStation(true); });

    const summary = el('textarea', { rows: '4', maxlength: '160', 'data-keep': 'summary', placeholder: 'Resume o problema com as tuas palavras técnicas…', 'aria-label': 'Resumo do problema' });
    const dept = el('select', { 'data-keep': 'dept', 'aria-label': 'Departamento' },
      el('option', { value: '', text: 'Selecionar departamento…' }),
      v.depts.map((d) => el('option', { value: d.key, text: d.label })));
    const send = btn('Enviar OS', 'btn-primary btn-wide', () => act('os_submit', { station: v.id, summary: summary.value, dept: dept.value }), true);
    const check = () => { send.disabled = summary.value.trim().length < 5 || !dept.value; };
    summary.addEventListener('input', check); dept.addEventListener('change', check);
    summary.addEventListener('keydown', (e) => e.stopPropagation());
    setTimeout(check, 0);

    body.append(el('div', { class: 'triage' },
      el('section', { class: 'pane' },
        el('div', { class: 'sec-title', text: `Chat com ${a.name}` }), bubbles,
        el('div', { class: 'chips' }, v.chips.map((q) => el('button', { class: 'chip', type: 'button', text: q, onclick: () => say(q) }))),
        sayForm),
      el('section', { class: 'pane os-form' },
        el('div', { class: 'sec-title', text: `Ordem de Serviço · ${a.os}` }),
        el('label', { text: 'Cliente' }), el('input', { type: 'text', value: a.name, readonly: true, tabindex: '-1' }),
        el('label', { text: 'Resumo do problema' }), summary,
        el('label', { text: 'Encaminhar para' }), dept,
        el('p', { class: 'hint left', text: 'Interpreta o relato: um erro de triagem custa tempo à equipa.' }),
        send,
        btn('← Voltar à lista', 'btn-outline btn-wide', () => act('chat_release', { station: v.id })))));
    setTimeout(() => { const b = $('#bubbles'); if (b) b.scrollTop = b.scrollHeight; }, 0);
  }

  // ==========================================================================
  // BANCADAS — inspeção, reencaminhamento e simulações
  // ==========================================================================
  const DEPT_ICON = { hardware: '🔧', software: '🛡️', network: '📶' };
  const DEPT_SUB = {
    hardware: 'Inspeciona a máquina e troca o componente avariado.',
    software: 'Analisa o sistema, executa o antivírus e isola as ameaças.',
    network: 'Diagnostica a ligação e corrige o IP ou o roteador.',
  };

  function simScreen(v, sim) {
    const steps = [['Retirar parafusos', sim.screws.every(Boolean)], ['Remover tela antiga', sim.removed],
      ['Escolher tela nova', !!sim.installed], ['Ligar cabo de vídeo', sim.connected], ['Testar', false]];
    const screen = el('div', { class: 'lid ' + (!sim.removed ? 'cracked' : !sim.installed ? 'empty' : 'fresh') },
      !sim.removed ? el('span', { class: 'crack-label', text: 'Tela danificada' })
        : !sim.installed ? el('span', { class: 'crack-label', text: 'Sem tela · conector exposto' })
          : el('span', { class: 'crack-label', text: sim.connected ? 'Tela nova ligada' : 'Tela nova instalada' }));
    if (!sim.removed) {
      sim.screws.forEach((done, i) => screen.append(el('button', { class: `screw s${i}` + (done ? ' off' : ''), type: 'button',
        title: done ? 'Parafuso retirado' : 'Retirar parafuso', 'aria-label': `Parafuso ${i + 1}`, disabled: !!done,
        onclick: () => act('sim', { station: v.id, act: 'unscrew', arg: i }) })));
    }
    let action;
    if (!sim.removed) action = btn('Remover tela antiga', 'btn-primary btn-wide', () => act('sim', { station: v.id, act: 'remove' }), !sim.screws.every(Boolean));
    else if (!sim.installed) {
      action = el('div', {}, el('div', { class: 'sec-title', text: 'Inventário de telas — confere a etiqueta do equipamento' }),
        el('div', { class: 'parts' }, sim.options.map((o) => el('button', { class: 'part', type: 'button',
          onclick: () => act('sim', { station: v.id, act: 'choose', arg: o.key }) }, el('span', { 'aria-hidden': 'true', text: '🖥️' }), o.label))));
    } else if (!sim.connected) action = btn('Ligar cabo de vídeo', 'btn-primary btn-wide', () => act('sim', { station: v.id, act: 'connect' }));
    else action = btn('Ligar o PC e testar', 'btn-primary btn-wide', () => act('sim', { station: v.id, act: 'test' }));
    return el('div', {},
      el('ol', { class: 'steps' }, steps.map(([t, d]) => el('li', { class: d ? 'done' : '', text: t }))),
      el('div', { class: 'laptop' }, screen, el('div', { class: 'base' })), action);
  }

  function simMalware(v, sim) {
    const win = (title, ...kids) => el('div', { class: 'win' }, el('div', { class: 'win-bar', text: title }), el('div', { class: 'win-body' }, kids));
    const desk = el('div', { class: 'desktop' });
    if (sim.phase === 'desktop') {
      for (let i = 0; i < sim.popups; i++) {
        desk.append(el('div', { class: `popup p${i}` }, el('b', { text: i % 2 ? 'ATENÇÃO: PC infetado!' : 'PARABÉNS! Ganhou um prémio!' }),
          el('button', { class: 'x', type: 'button', 'aria-label': 'Fechar janela', text: '✕', onclick: () => act('sim', { station: v.id, act: 'close_popup' }) })));
      }
      desk.append(el('div', { class: 'icons' },
        el('div', { class: 'icon' }, el('span', { text: '📁' }), 'Documentos'),
        el('div', { class: 'icon' }, el('span', { text: '🌐' }), 'Navegador'),
        el('button', { class: 'icon av', type: 'button', onclick: () => act('sim', { station: v.id, act: 'open_av' }) }, el('span', { text: '🛡️' }), 'SecureScan')));
    } else if (sim.phase === 'av') {
      desk.append(win('SecureScan Antivírus', el('p', { text: 'Pronto para analisar o sistema.' }),
        btn('Executar verificação completa', 'btn-primary', () => act('sim', { station: v.id, act: 'run_scan' }))));
    } else if (sim.phase === 'scanning') {
      desk.append(win('SecureScan Antivírus', el('p', { text: 'A analisar ficheiros…' }), timedBar(sim.msLeft, sim.total, 'up')));
    } else {
      const allQ = sim.files.length && sim.files.every((f) => f.q);
      desk.append(win('SecureScan · Resultados', el('p', { class: 'hint left', text: 'Lê as descrições: nem tudo o que é sinalizado é malicioso.' }),
        el('div', { class: 'files' }, sim.files.map((f) => el('div', { class: 'file' + (f.q ? ' q' : '') },
          el('div', { class: 'grow' }, el('b', { text: f.name }), el('small', { text: f.note })),
          el('span', { class: 'badge', text: 'Risco ' + f.risk }),
          btn(f.q ? '✔ Quarentena' : 'Quarentena', f.q ? 'btn-outline' : 'btn-danger', () => act('sim', { station: v.id, act: 'quarantine', arg: f.id }), f.q)))),
        btn('Concluir limpeza', 'btn-primary btn-wide', () => act('sim', { station: v.id, act: 'finish' }), false), allQ ? null : null));
    }
    desk.append(el('div', { class: 'taskbar', text: sim.phase === 'desktop' ? 'Windows · Sistema suspeito' : 'Windows · SecureScan' }));
    return desk;
  }

  function simWifi(v, sim) {
    const chip = (ok, t) => el('span', { class: 'status' + (ok ? '' : ' bad'), text: t });
    const sendS = (a, arg) => act('sim', { station: v.id, act: a, arg });
    const net = el('div', { class: 'win' }, el('div', { class: 'win-bar', text: 'Configurações de rede' }),
      el('div', { class: 'win-body' },
        el('div', { class: 'kv' }, el('span', { text: 'Adaptador Wi-Fi' }), chip(sim.adapter === 'Conectado', sim.adapter)),
        el('div', { class: 'kv' }, el('span', { text: 'IPv4' }), el('b', { text: sim.ip })),
        el('div', { class: 'kv' }, el('span', { text: 'Gateway' }), el('b', { text: sim.gateway })),
        el('div', { class: 'tools' },
          btn('ipconfig', 'btn-outline', () => sendS('ipconfig')),
          btn('Ping gateway', 'btn-outline', () => sendS('ping', 'gateway')),
          btn('Ping internet', 'btn-outline', () => sendS('ping', 'internet')),
          btn('Renovar IP (DHCP)', 'btn-outline', () => sendS('renew_ip')))));
    const router = el('div', { class: 'win' }, el('div', { class: 'win-bar', text: 'Painel do roteador' }),
      el('div', { class: 'win-body' },
        el('div', { class: 'leds' },
          el('div', {}, el('i', { class: 'led on' }), 'Energia'), el('div', {}, el('i', { class: 'led on' }), 'LAN'),
          el('div', {}, el('i', { class: 'led ' + (sim.wan === 'Online' ? 'on' : 'bad') }), 'WAN: ' + sim.wan)),
        btn('Reiniciar roteador', 'btn-outline', () => sendS('restart_router'))));
    const log = el('div', { class: 'console', id: 'net-log' }, sim.log.map((l) => el('div', { text: l })));
    setTimeout(() => { const c = $('#net-log'); if (c) c.scrollTop = c.scrollHeight; }, 0);
    return el('div', {}, el('div', { class: 'net-grid' }, net, router), log,
      btn('Testar ligação', 'btn-primary btn-wide', () => sendS('test')));
  }

  function buildBench(v, body) {
    $('#sm-icon').textContent = DEPT_ICON[v.dept];
    $('#sm-sub').textContent = DEPT_SUB[v.dept];
    if (v.item) body.append(ticketCard(v.item, true));
    if (v.phase === 1 && !v.inspected) {
      body.append(el('div', { class: 'sec-title', text: 'Equipamento recebido' }),
        el('p', { class: 'hint left', text: 'Confirma se o problema pertence mesmo ao teu departamento antes de começar.' }),
        el('div', { class: 'big-actions' },
          btn('Inspecionar equipamento', 'btn-primary btn-wide', () => act('inspect', { station: v.id })),
          btn('Retirar máquina da bancada', 'btn-outline btn-wide', () => act('bench_collect', { station: v.id }))));
    } else if (v.phase === 1 && v.mismatch) {
      body.append(el('div', { class: 'alert' }, el('b', { text: 'Triagem incorreta' }),
        el('p', { text: `A inspeção mostra um problema de ${v.actualLabel}. Esta máquina não é do teu departamento.` })),
        el('div', { class: 'big-actions' }, btn(`Reencaminhar para ${v.actualLabel}`, 'btn-primary btn-wide', () => act('reroute', { station: v.id, dept: v.actualDept }))));
    } else if (v.phase === 2 && v.sim) {
      const r = { screen: simScreen, malware: simMalware, wifi: simWifi }[v.sim.type];
      body.append(el('div', { class: 'sec-title', text: 'Simulação técnica' }), r(v, v.sim));
    } else if (v.phase === 3) {
      body.append(el('div', { class: 'sec-title', text: 'Reparo concluído ✔' }),
        el('p', { class: 'hint left', text: 'Leva a máquina à Mesa de Saída para a Recepção entregar ao cliente.' }),
        el('div', { class: 'big-actions' }, btn('Recolher PC', 'btn-primary btn-wide', () => act('bench_collect', { station: v.id }))));
    }
  }

  function buildDelivery(v, body) {
    $('#sm-icon').textContent = '📦';
    $('#sm-sub').textContent = 'Devolve o PC reparado ao cliente. A satisfação depende da qualidade do atendimento.';
    if (!v.item) { body.append(el('div', { class: 'empty', text: 'Não estás a carregar nenhum PC.' })); return; }
    body.append(ticketCard(v.item, v.item.repaired),
      el('div', { class: 'big-actions' }, btn(v.item.repaired ? `Entregar a ${v.item.customer}` : 'Este PC ainda não está reparado', 'btn-primary btn-wide',
        () => act('deliver', { station: v.id }), !v.item.repaired)));
  }

  const BUILDERS = { counter: buildCounter, bench: buildBench, delivery: buildDelivery };

  UI.openStation = (v) => {
    const sig = sigOf(v);
    if (cur && cur.view.id === v.id && cur.sig === sig && !$('#station-modal').hidden) { cur.view = v; return; }

    // preserva texto digitado e foco entre atualizações do servidor
    const body = $('#sm-body');
    const keep = {}; let focusKey = null, selStart = 0;
    if (cur && cur.view.id === v.id) {
      body.querySelectorAll('[data-keep]').forEach((n) => { keep[n.dataset.keep] = n.value; });
      const f = document.activeElement;
      if (f && f.dataset && f.dataset.keep) { focusKey = f.dataset.keep; selStart = f.selectionStart; }
    }
    cur = { view: v, sig, at: performance.now() };
    lastStep = -1;
    $('#sm-title').textContent = v.label;
    $('#station-modal .modal').classList.toggle('wide', v.type !== 'delivery');
    body.innerHTML = '';
    BUILDERS[v.type](v, body);
    body.querySelectorAll('[data-keep]').forEach((n) => { if (keep[n.dataset.keep] != null) n.value = keep[n.dataset.keep]; });
    if (focusKey) { const n = body.querySelector(`[data-keep="${focusKey}"]`); if (n) { n.focus(); try { n.setSelectionRange(selStart, selStart); } catch (_) { /* select */ } } }
    else if (v.type === 'counter' && v.active) setTimeout(() => { const n = body.querySelector('[data-keep="say"]'); if (n) n.focus(); }, 30);
    $('#station-modal').hidden = false;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(tickBars);
  };

  UI.closeStation = (notify) => {
    if (!cur && $('#station-modal').hidden) return;
    cur = null; cancelAnimationFrame(raf);
    $('#station-modal').hidden = true; $('#sm-body').innerHTML = '';
    if (notify && UI.on.uiClose) UI.on.uiClose();
  };
  $('#sm-close').addEventListener('click', () => UI.closeStation(true));
  $('#station-modal').addEventListener('mousedown', (e) => { if (e.target.id === 'station-modal') UI.closeStation(true); });

  /** Anima as barras entre atualizações do servidor (a verificação do antivírus). */
  function tickBars() {
    if (!cur) return;
    const elapsed = performance.now() - cur.at;
    for (const bar of $('#sm-body').querySelectorAll('.bar[data-total]')) {
      const left = Number(bar.dataset.left) - elapsed, total = Number(bar.dataset.total) || 1;
      let frac = Math.min(1, Math.max(0, left / total));
      if (bar.dataset.mode === 'up') frac = 1 - frac;
      bar.firstChild.style.width = (frac * 100).toFixed(1) + '%';
    }
    raf = requestAnimationFrame(tickBars);
  }

  // ==========================================================================
  // MEU PERSONAGEM
  // ==========================================================================
  const PT = {
    base: { male: 'Homem', female: 'Mulher' },
    shirt: { purple: 'Roxo', white: 'Branco', blue: 'Azul', green: 'Verde', orange: 'Laranja', red: 'Vermelho' },
    pants: { dark: 'Escuro', navy: 'Azul-marinho', khaki: 'Cáqui', gray: 'Cinza' },
    hair: { black: 'Preto', brown: 'Castanho', blonde: 'Loiro', red: 'Ruivo', gray: 'Grisalho' },
    skin: { light: 'Clara', tan: 'Bronzeada', brown: 'Castanha', dark: 'Escura' },
    accessory: { none: 'Nenhum', glasses: 'Óculos', headset: 'Headset', cap: 'Boné', tie: 'Gravata' },
  };
  const GROUPS = [['base', 'Base'], ['skin', 'Pele'], ['hair', 'Cabelo'], ['shirt', 'Camisa'], ['pants', 'Calça'], ['accessory', 'Acessório']];
  let draft = null;

  function buildOptions() {
    const box = $('#char-options');
    box.innerHTML = '';
    for (const [key, title] of GROUPS) {
      const row = el('div', { class: 'row' });
      const entries = Array.isArray(S.CUSTOMIZATION[key]) ? S.CUSTOMIZATION[key].map((k) => [k, null]) : Object.entries(S.CUSTOMIZATION[key]);
      for (const [k, color] of entries) {
        const b = color == null
          ? el('button', { class: 'chip', type: 'button', text: PT[key][k] })
          : el('button', { class: 'swatch', type: 'button', title: PT[key][k], 'aria-label': PT[key][k], style: `background:${hex(color)}` });
        b.setAttribute('aria-pressed', String(draft[key] === k));
        b.addEventListener('click', () => {
          draft[key] = k;
          row.querySelectorAll('[aria-pressed]').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
          UI.on.previewChange && UI.on.previewChange({ ...draft });
        });
        row.append(b);
      }
      box.append(el('div', {}, el('h3', { text: title }), row));
    }
  }
  UI.openCharacter = (custom) => {
    draft = { ...custom }; buildOptions();
    $('#character-modal').hidden = false;
    UI.on.openPreview && UI.on.openPreview({ ...draft });
  };
  UI.closeCharacter = () => { $('#character-modal').hidden = true; UI.on.closePreview && UI.on.closePreview(); };
  $('#btn-character').addEventListener('click', () => UI.openCharacter(UI.myCustom || UI.loadSaved().custom));
  $('#cm-close').addEventListener('click', UI.closeCharacter);
  $('#cm-random').addEventListener('click', () => {
    draft = { base: rnd(S.CUSTOMIZATION.base), accessory: rnd(S.CUSTOMIZATION.accessory) };
    for (const k of ['shirt', 'pants', 'hair', 'skin']) draft[k] = rnd(Object.keys(S.CUSTOMIZATION[k]));
    buildOptions();
    UI.on.previewChange && UI.on.previewChange({ ...draft });
  });
  $('#cm-save').addEventListener('click', () => {
    const c = S.sanitizeCustom(draft);
    store.set('tic.custom', c); UI.myCustom = c;
    UI.on.customize && UI.on.customize(c);
    UI.closeCharacter();
  });
  UI.setMyCustom = (c) => { UI.myCustom = c; };

  // ==========================================================================
  // TECLADO GLOBAL
  // ==========================================================================
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && joined && !UI.typing && !UI.modalOpen()) { e.preventDefault(); $('#chat-input').focus(); }
    if (e.key === 'Escape') {
      if (!$('#character-modal').hidden) UI.closeCharacter();
      else if (!$('#station-modal').hidden) UI.closeStation(true);
      else if (document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) document.activeElement.blur();
    }
  });

  window.UI = UI;
})();
