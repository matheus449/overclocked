/**
 * shared/shared.js (v3) — código ISOMÓRFICO (Node + browser)
 * Fonte única de verdade para: constantes de rede, mapa, física determinística,
 * departamentos, catálogo de customização e opções das simulações.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Shared = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ---------- Rede / simulação ----------
  const TICK_RATE = 60;
  const SNAPSHOT_RATE = 20;
  const DT = 1 / TICK_RATE;

  // ---------- Jogador ----------
  const PLAYER_SPEED = 5.2;
  const PLAYER_RADIUS = 0.4;
  const INTERACT_RANGE = 1.5;

  // ---------- Mundo ----------
  const WORLD = { halfW: 18, halfD: 12 };

  // ---------- Funções = departamentos ----------
  // O nome da função de um técnico É a chave do departamento para onde a OS é encaminhada.
  const ROLES = ['reception', 'hardware', 'software', 'network'];
  const DEPTS = ['hardware', 'software', 'network'];
  const ROLE_LIMITS = { reception: 3, hardware: 4, software: 4, network: 3 };   // soma = 14
  const ROLE_LABEL = { reception: 'Recepção', hardware: 'Hardware', software: 'Software/Segurança', network: 'Redes' };
  const MAX_PLAYERS = 14;

  // ---------- Catálogos ----------
  const SCREEN_OPTIONS = [
    { key: '14',   label: 'Tela 14″ HD' },
    { key: '15.6', label: 'Tela 15.6″ Full HD' },
    { key: '17',   label: 'Tela 17″ 4K' },
  ];
  // Perguntas rápidas da Recepção ao cliente (o texto livre também é interpretado)
  const QUICK_QUESTIONS = [
    'Quando isso começou?',
    'O computador liga normalmente?',
    'Já tentou reiniciar?',
    'Aconteceu algum acidente ou queda?',
    'Os outros aparelhos funcionam?',
    'Aparecem mensagens ou janelas estranhas?',
  ];

  // ---------- Customização do avatar (agênera) ----------
  const CUSTOMIZATION = {
    base: ['male', 'female'],
    shirt: { purple: 0x7c3aed, white: 0xf4f5f8, blue: 0x3b82f6, green: 0x22c55e, orange: 0xf59e0b, red: 0xef4444 },
    pants: { dark: 0x1f2937, navy: 0x1e3a8a, khaki: 0xb59b6a, gray: 0x6b7280 },
    hair:  { black: 0x1a1a1a, brown: 0x5b3a1e, blonde: 0xe3c27a, red: 0xb4441f, gray: 0x9ca3af },
    skin:  { light: 0xf2d3b3, tan: 0xd9a679, brown: 0x9a6a43, dark: 0x5e3b26 },
    accessory: ['none', 'glasses', 'headset', 'cap', 'tie'],
  };
  const DEFAULT_CUSTOM = { base: 'male', shirt: 'purple', pants: 'dark', hair: 'brown', skin: 'light', accessory: 'none' };

  function sanitizeCustom(c) {
    const out = Object.assign({}, DEFAULT_CUSTOM);
    if (!c || typeof c !== 'object') return out;
    if (CUSTOMIZATION.base.includes(c.base)) out.base = c.base;
    for (const k of ['shirt', 'pants', 'hair', 'skin']) {
      if (typeof c[k] === 'string' && Object.prototype.hasOwnProperty.call(CUSTOMIZATION[k], c[k])) out[k] = c[k];
    }
    if (CUSTOMIZATION.accessory.includes(c.accessory)) out.accessory = c.accessory;
    return out;
  }

  // ---------- Estações ----------
  // type: counter | table | bench | delivery
  // table.kind: 'in' (triagem: só o servidor coloca; técnico do dept recolhe) | 'out' (saída: técnico deixa, Recepção recolhe)
  // bench.role = departamento que opera a bancada
  const STATIONS = [
    { id: 'counter',  type: 'counter',  role: 'reception', label: 'Balcão de Atendimento', x: -15, z: -9, w: 3.0, d: 1.4 },
    { id: 'T_in',     type: 'table', kind: 'in',  slots: 4, role: null, label: 'Mesa de Triagem', x: -11, z: -4, w: 3.6, d: 1.2 },

    { id: 'H1', type: 'bench', role: 'hardware', label: 'Bancada de Hardware 1', x: -4, z: -8, w: 2.4, d: 1.4 },
    { id: 'H2', type: 'bench', role: 'hardware', label: 'Bancada de Hardware 2', x:  0, z: -8, w: 2.4, d: 1.4 },
    { id: 'H3', type: 'bench', role: 'hardware', label: 'Bancada de Hardware 3', x:  4, z: -8, w: 2.4, d: 1.4 },

    { id: 'S1', type: 'bench', role: 'software', label: 'Bancada de Software 1', x: -4, z:  8, w: 2.4, d: 1.4 },
    { id: 'S2', type: 'bench', role: 'software', label: 'Bancada de Software 2', x:  0, z:  8, w: 2.4, d: 1.4 },
    { id: 'S3', type: 'bench', role: 'software', label: 'Bancada de Software 3', x:  4, z:  8, w: 2.4, d: 1.4 },

    { id: 'N1', type: 'bench', role: 'network', label: 'Bancada de Redes 1', x: 13, z: -6, w: 1.6, d: 2.4 },
    { id: 'N2', type: 'bench', role: 'network', label: 'Bancada de Redes 2', x: 13, z:  0, w: 1.6, d: 2.4 },
    { id: 'N3', type: 'bench', role: 'network', label: 'Bancada de Redes 3', x: 13, z:  6, w: 1.6, d: 2.4 },

    { id: 'T_out',    type: 'table', kind: 'out', slots: 4, role: null, label: 'Mesa de Saída', x: -11, z: 5, w: 3.6, d: 1.2 },
    { id: 'delivery', type: 'delivery', role: 'reception', label: 'Balcão do Cliente', x: -15, z: 9, w: 3.0, d: 1.4 },
  ];

  const DECOR = [
    { id: 'D1', kind: 'desk', x: 8, z: -4.5, w: 2.4, d: 1.2 },
    { id: 'D2', kind: 'desk', x: 8, z: -2.0, w: 2.4, d: 1.2 },
    { id: 'D3', kind: 'desk', x: 8, z:  2.0, w: 2.4, d: 1.2 },
    { id: 'D4', kind: 'desk', x: 8, z:  4.5, w: 2.4, d: 1.2 },
    { id: 'M1', kind: 'meeting', x: 9.5, z: -9.5, w: 3.0, d: 1.6 },
    { id: 'R1', kind: 'rack', x: 16.8, z: -3, w: 1.2, d: 2.0 },
    { id: 'R2', kind: 'rack', x: 16.8, z:  3, w: 1.2, d: 2.0 },
    { id: 'P1', kind: 'plant', x: -17, z: -11, w: 0.8, d: 0.8 },
    { id: 'P2', kind: 'plant', x: -17, z:  11, w: 0.8, d: 0.8 },
    { id: 'P3', kind: 'plant', x:  17, z: -11, w: 0.8, d: 0.8 },
    { id: 'P4', kind: 'plant', x:  17, z:  11, w: 0.8, d: 0.8 },
    { id: 'P5', kind: 'plant', x:   9, z:   8, w: 0.8, d: 0.8 },
    { id: 'P6', kind: 'plant', x: -7.5, z:  0, w: 0.8, d: 0.8 },
  ];
  const OBSTACLES = STATIONS.concat(DECOR);

  // Menu de navegação (UI): o cliente mostra um farol no local
  const ZONES = [
    { id: 'atendimento', icon: '🛎️', label: 'Balcão de Atendimento', x: -15,   z: -7.2 },
    { id: 'triagem',     icon: '🗂️', label: 'Mesa de Triagem',       x: -11,   z: -2.4 },
    { id: 'hardware',    icon: '🔧', label: 'Bancadas de Hardware',  x:   0,   z: -6.4 },
    { id: 'software',    icon: '🛡️', label: 'Bancadas de Software',  x:   0,   z:  6.4 },
    { id: 'redes',       icon: '📶', label: 'Bancadas de Redes',     x:  11.2, z:  0 },
    { id: 'saida',       icon: '📤', label: 'Mesa de Saída',         x: -11,   z:  3.3 },
    { id: 'entrega',     icon: '📦', label: 'Balcão do Cliente',     x: -15,   z:  7.2 },
    { id: 'reuniao',     icon: '🗣️', label: 'Reunião',               x:  9.5,  z: -7.6 },
  ];

  function spawnPoint(index) {
    const k = index % MAX_PLAYERS;
    return { x: -6 + (k % 7) * 2, y: 0, z: k < 7 ? 3 : 4.6 };
  }

  function distToRect(px, pz, o) {
    const dx = Math.max(Math.abs(px - o.x) - o.w / 2, 0);
    const dz = Math.max(Math.abs(pz - o.z) - o.d / 2, 0);
    return Math.hypot(dx, dz);
  }

  function collides(x, z) {
    const r = PLAYER_RADIUS;
    if (x < -WORLD.halfW + r || x > WORLD.halfW - r) return true;
    if (z < -WORLD.halfD + r || z > WORLD.halfD - r) return true;
    for (let i = 0; i < OBSTACLES.length; i++) if (distToRect(x, z, OBSTACLES[i]) < r) return true;
    return false;
  }

  /** Passo DETERMINÍSTICO (servidor e cliente usam a mesma função => predição sem erro). */
  function stepPlayer(p, input, dt) {
    let dx = Number(input.dx), dz = Number(input.dz);
    if (!Number.isFinite(dx) || !Number.isFinite(dz)) { dx = 0; dz = 0; }
    const len = Math.hypot(dx, dz);
    if (len > 1) { dx /= len; dz /= len; }
    if (len > 0.001) p.ry = Math.atan2(dx, dz);
    const nx = p.x + dx * PLAYER_SPEED * dt;
    if (!collides(nx, p.z)) p.x = nx;
    const nz = p.z + dz * PLAYER_SPEED * dt;
    if (!collides(p.x, nz)) p.z = nz;
  }

  return {
    TICK_RATE, SNAPSHOT_RATE, DT, PLAYER_SPEED, PLAYER_RADIUS, INTERACT_RANGE,
    WORLD, ROLES, DEPTS, ROLE_LIMITS, ROLE_LABEL, MAX_PLAYERS,
    SCREEN_OPTIONS, QUICK_QUESTIONS, CUSTOMIZATION, DEFAULT_CUSTOM, sanitizeCustom,
    STATIONS, DECOR, OBSTACLES, ZONES,
    spawnPoint, distToRect, collides, stepPlayer,
  };
});
