/**
 * public/js/game.js (v3) — Cliente: Canvas (Three.js) + rede (Socket.io)
 * ----------------------------------------------------------------------------
 * ANTI-LAG (inalterado):
 *  A) Jogador local: predição (Shared.stepPlayer) + reconciliação por `ack`;
 *     o erro residual dissolve-se em `offset` (sem saltos).
 *  B) Jogadores remotos: interpolação com atraso fixo (INTERP_DELAY = 100 ms)
 *     entre dois snapshots de 20 Hz.
 *  C) Passo fixo de 60 Hz com render interpolado (alpha = acc / DT).
 *
 * v3: clientes NPC na fila do balcão, mesas de Triagem/Saída, bancadas de Redes e
 * eventos direcionados (`client_arrived` só para a Recepção, `notify_task` só para
 * o departamento escolhido — o servidor usa salas do Socket.io).
 * ----------------------------------------------------------------------------
 */
(() => {
  'use strict';
  const S = window.Shared;
  const UI = window.UI;

  const INTERP_DELAY = 100;
  const PURPLE = 0x7c3aed;
  const ROLE_COLOR = { reception: 0x3b82f6, hardware: 0xf59e0b, software: 0x7c3aed, network: 0x14b8a6 };
  const CODE_COLOR = { 1: 0xf59e0b, 2: 0x7c3aed, 3: 0x14b8a6, 4: 0x22c55e };   // dept. de destino; 4 = reparado
  const SQ2 = Math.SQRT2;

  // ==========================================================================
  // 1) CENA / CÂMARA
  // ==========================================================================
  const canvas = document.getElementById('game');
  const labelsEl = document.getElementById('labels');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xdde3f0);

  const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 200);
  camera.position.set(30, 30, 30);
  camera.lookAt(0, 0, 0);

  function resize() {
    const w = window.innerWidth, h = window.innerHeight, aspect = w / h;
    renderer.setSize(w, h, false);
    const viewH = Math.max(32, 50 / aspect);
    camera.left = (-viewH * aspect) / 2; camera.right = (viewH * aspect) / 2;
    camera.top = viewH / 2; camera.bottom = -viewH / 2;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  scene.add(new THREE.AmbientLight(0xffffff, 0.78));
  const sun = new THREE.DirectionalLight(0xffffff, 0.72);
  sun.castShadow = true;
  sun.shadow.camera.near = 0.5;
  sun.shadow.camera.far = 120;
  sun.shadow.camera.left = -25;
  sun.shadow.camera.right = 25;
  sun.shadow.camera.top = 20;
  sun.shadow.camera.bottom = -20;
  sun.shadow.mapSize.width = 2048;
  sun.shadow.mapSize.height = 2048;
  sun.shadow.bias = -0.001;
  sun.position.set(12, 26, 8);
  scene.add(sun);

  const _v = new THREE.Vector3();
  function makeLabel(cls, text) {
    const el = document.createElement('div');
    el.className = 'label ' + cls;
    const e = document.createElement('span'); e.className = 'lemote';
    const t = document.createElement('span'); t.className = 'ltext'; t.textContent = text;
    el.append(e, t);
    labelsEl.appendChild(el);
    return { el, t, e };
  }
  function placeLabel(l, x, y, z) {
    _v.set(x, y, z).project(camera);
    if (_v.z > 1) { l.el.style.display = 'none'; return; }
    l.el.style.display = '';
    l.el.style.transform =
      `translate(${(_v.x * 0.5 + 0.5) * window.innerWidth}px, ${(-_v.y * 0.5 + 0.5) * window.innerHeight}px) translate(-50%, -100%)`;
  }

  // ==========================================================================
  // 2) ESCRITÓRIO
  // ==========================================================================
  const B = (w, h, d) => new THREE.BoxGeometry(w, h, d);
  const lam = (c) => new THREE.MeshLambertMaterial({ color: c });
  function box(w, h, d, color, x, y, z, parent, shadows) {
    const m = new THREE.Mesh(B(w, h, d), lam(color));
    m.position.set(x || 0, y || 0, z || 0);
    if (shadows !== false) { m.castShadow = true; m.receiveShadow = true; }
    (parent || scene).add(m);
    return m;
  }

  function makeWoodTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 512;
    const g = c.getContext('2d');
    let seed = 7;
    const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    const rows = 8, rh = 512 / rows;
    for (let r = 0; r < rows; r++) {
      let x = -rand() * 200;
      while (x < 512) {
        const len = 150 + rand() * 150;
        g.fillStyle = `hsl(35, ${38 + rand() * 12}%, ${72 + rand() * 8}%)`;
        g.fillRect(x, r * rh, len, rh);
        g.strokeStyle = 'rgba(140, 100, 60, .35)'; g.lineWidth = 2; g.strokeRect(x, r * rh, len, rh);
        g.strokeStyle = 'rgba(150, 110, 70, .12)'; g.lineWidth = 1;
        for (let k = 0; k < 3; k++) {
          const yy = r * rh + 8 + rand() * (rh - 16);
          g.beginPath(); g.moveTo(x + 4, yy); g.lineTo(x + len - 4, yy + (rand() - 0.5) * 4); g.stroke();
        }
        x += len;
      }
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    return tex;
  }

  function makeMonitor() {
    const g = new THREE.Group();
    box(0.95, 0.58, 0.06, PURPLE, 0, 0, 0, g);
    box(0.84, 0.46, 0.02, 0x1e1b4b, 0, 0, 0.035, g);
    const glow = new THREE.Mesh(B(0.5, 0.04, 0.01), new THREE.MeshBasicMaterial({ color: 0xa78bfa }));
    glow.position.set(-0.1, 0.1, 0.05); g.add(glow);
    box(0.12, 0.24, 0.1, 0xd1d5db, 0, -0.4, -0.02, g);
    box(0.4, 0.03, 0.26, 0xd1d5db, 0, -0.53, 0, g);
    return g;
  }
  function makeChair() {
    const g = new THREE.Group();
    box(0.62, 0.1, 0.62, PURPLE, 0, 0.55, 0, g);
    box(0.62, 0.72, 0.1, 0x6d28d9, 0, 0.95, -0.3, g);
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.42, 8), lam(0x9ca3af));
    post.position.y = 0.3; g.add(post);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.05, 12), lam(0x6b7280));
    base.position.y = 0.04; g.add(base);
    return g;
  }
  function makePlant(x, z) {
    const g = new THREE.Group();
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.22, 0.45, 12), lam(0xf3f4f6));
    pot.position.y = 0.225; g.add(pot);
    const leaf = (r, px, py, pz, c) => { const m = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), lam(c)); m.position.set(px, py, pz); g.add(m); };
    leaf(0.38, 0, 0.8, 0, 0x22c55e); leaf(0.28, 0.18, 1.1, 0.05, 0x16a34a);
    leaf(0.25, -0.16, 1.05, -0.1, 0x4ade80); leaf(0.2, 0, 1.35, 0, 0x22c55e);
    g.position.set(x, 0, z); scene.add(g);
  }

  function buildOffice() {
    const { halfW, halfD } = S.WORLD;
    const wood = makeWoodTexture();
    wood.repeat.set((halfW * 2) / 6, (halfD * 2) / 6);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(halfW * 2, halfD * 2), new THREE.MeshLambertMaterial({ map: wood }));
    floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

    // Grid overlay for spatial orientation
    const gridHelper = new THREE.GridHelper(36, 18, 0xc5cde0, 0xd8dff0);
    gridHelper.position.y = 0.01;
    gridHelper.material.transparent = true; gridHelper.material.opacity = 0.55;
    scene.add(gridHelper);

    const WALL = 0xc8d4e6;
    box(0.4, 4.2, halfD * 2 + 0.8, WALL, -halfW - 0.2, 2.1, 0);
    box(halfW * 2 + 0.8, 4.2, 0.4, WALL, 0, 2.1, -halfD - 0.2);
    box(0.4, 0.6, halfD * 2 + 0.8, WALL, halfW + 0.2, 0.3, 0);
    box(halfW * 2 + 0.8, 0.6, 0.4, WALL, 0, 0.3, halfD + 0.2);
    box(0.3, 0.25, halfD * 2, 0xffffff, -halfW + 0.15, 0.125, 0);
    box(halfW * 2, 0.25, 0.3, 0xffffff, 0, 0.125, -halfD + 0.15);

    const glassMat = new THREE.MeshBasicMaterial({ color: 0xbfe2ff });
    const windowAt = (x, z, alongX) => {
      const g = new THREE.Group(), w = 3.4, h = 2.0;
      box(alongX ? w + 0.3 : 0.12, h + 0.3, alongX ? 0.12 : w + 0.3, 0xffffff, 0, 0, 0, g);
      g.add(new THREE.Mesh(B(alongX ? w : 0.14, h, alongX ? 0.14 : w), glassMat));
      box(alongX ? 0.08 : 0.16, h, alongX ? 0.16 : 0.08, 0xffffff, 0, 0, 0, g);
      box(alongX ? w : 0.16, 0.08, alongX ? 0.16 : w, 0xffffff, 0, 0, 0, g);
      g.position.set(x, 2.5, z); scene.add(g);
    };
    for (const x of [-12, -4, 4, 12]) windowAt(x, -halfD + 0.02, true);
    for (const z of [-6, 0, 6]) windowAt(-halfW + 0.02, z, false);

    for (const d of S.DECOR) {
      if (d.kind === 'plant') makePlant(d.x, d.z);
      else if (d.kind === 'rack' || d.kind === 'desk') { /* removed for cleaner look */
      } else if (d.kind === 'meeting') { /* removed */ }
    }
  }
  buildOffice();

  // ---------- estações ----------
  const HEIGHT = { counter: 1.15, delivery: 1.15, table: 0.9, bench: 1.0 };
  /** Direção do lado onde o jogador se coloca (a frente da estação). */
  const FACE = (s) => (s.type === 'counter' ? [0, 1] : s.type === 'delivery' ? [0, -1]
    : s.type === 'bench' ? (Math.abs(s.x) > 9 ? [-Math.sign(s.x), 0] : [0, s.z < 0 ? 1 : -1]) : [0, 0]);

  const views = new Map();   // stationId -> { s, h, slots[], label, base, top }

  function buildStations() {
    for (const s of S.STATIONS) {
      const h = HEIGHT[s.type];
      const [fx, fz] = FACE(s);
      const accent = s.role ? ROLE_COLOR[s.role] : PURPLE;

      box(s.w, h - 0.08, s.d, 0xf7f7fb, s.x, (h - 0.08) / 2, s.z);
      box(s.w + 0.08, 0.05, s.d + 0.08, 0xdde3ef, s.x, h - 0.1, s.z);
      const top = box(s.w + 0.06, 0.08, s.d + 0.06, 0xeef0f6, s.x, h - 0.04, s.z);

      if (s.role) {                                                // faixa com a cor do departamento
        const strip = new THREE.Mesh(B(fx ? 0.05 : s.w * 0.8, 0.16, fx ? s.d * 0.8 : 0.05), new THREE.MeshBasicMaterial({ color: accent }));
        strip.position.set(s.x + fx * (s.w / 2 + 0.03), h * 0.45, s.z + fz * (s.d / 2 + 0.03));
        scene.add(strip);
      }
      if (s.type === 'bench') {
        const half = (fx ? s.w : s.d) / 2;
        const mon = makeMonitor();                                 // monitor virado para o técnico
        mon.position.set(s.x - fx * (half - 0.25), h + 0.62, s.z - fz * (half - 0.25));
        mon.rotation.y = Math.atan2(fx, fz); scene.add(mon);
        box(fx ? 0.22 : 0.7, 0.04, fx ? 0.7 : 0.22, 0xe5e7eb, s.x + fx * 0.35 + (fx ? 0 : -0.7), h + 0.02, s.z + fz * 0.35 + (fx ? -0.5 : 0));
        const chair = makeChair();
        chair.position.set(s.x + fx * (half + 0.45) + (fx ? 0 : 0.9), 0, s.z + fz * (half + 0.45) + (fx ? 0.9 : 0));
        chair.rotation.y = Math.atan2(-fx, -fz); scene.add(chair);
      }
      if (s.type === 'counter' || s.type === 'delivery') {
        const mon = makeMonitor();
        mon.position.set(s.x + 0.8, h + 0.62, s.z);
        mon.rotation.y = Math.atan2(-fx, -fz); scene.add(mon);
      }

      const slots = [];
      const n = s.type === 'table' ? s.slots : s.type === 'bench' ? 1 : 0;
      for (let i = 0; i < n; i++) {
        const pc = box(0.55, 0.42, 0.55, 0xffffff, n === 1 ? s.x + 0.1 : s.x + (i - (n - 1) / 2) * (s.w / n), h + 0.21, s.z);
        pc.visible = false;
        slots.push(pc);
      }
      const lab = makeLabel('station', s.label);
      views.set(s.id, { s, h, slots, label: lab, base: s.label, top });
    }
  }
  buildStations();

  // ==========================================================================
  // 3) AVATARES EM BLOCOS (customizáveis) — jogadores e clientes NPC
  // ==========================================================================
  function buildAvatar(c) {
    const C = S.CUSTOMIZATION;
    const g = new THREE.Group();
    const M = (h) => new THREE.MeshLambertMaterial({ color: h });
    const skin = M(C.skin[c.skin]), shirt = M(C.shirt[c.shirt]), pants = M(C.pants[c.pants]), hair = M(C.hair[c.hair]);
    const dark = M(0x111827), purple = M(PURPLE);
    const add = (parent, w, h, d, mat, x, y, z) => { const m = new THREE.Mesh(B(w, h, d), mat); m.position.set(x, y, z); parent.add(m); return m; };
    const fem = c.base === 'female';
    const tw = fem ? 0.5 : 0.6;

    const leg = (x) => { const l = new THREE.Group(); l.position.set(x, 0.7, 0); add(l, 0.25, 0.7, 0.27, pants, 0, -0.35, 0); add(l, 0.26, 0.12, 0.33, dark, 0, -0.64, 0.03); g.add(l); return l; };
    const legL = leg(-0.15), legR = leg(0.15);
    add(g, tw, 0.7, 0.32, shirt, 0, 1.05, 0);
    const arm = (x) => { const a = new THREE.Group(); a.position.set(x, 1.38, 0); add(a, 0.2, 0.45, 0.24, shirt, 0, -0.2, 0); add(a, 0.18, 0.25, 0.22, skin, 0, -0.52, 0); g.add(a); return a; };
    const armL = arm(-(tw / 2 + 0.12)), armR = arm(tw / 2 + 0.12);

    const head = new THREE.Group(); head.position.y = 1.65; g.add(head);
    add(head, 0.5, 0.5, 0.5, skin, 0, 0, 0);
    add(head, 0.07, 0.09, 0.02, dark, -0.12, 0.04, 0.255);
    add(head, 0.07, 0.09, 0.02, dark, 0.12, 0.04, 0.255);
    add(head, 0.14, 0.03, 0.02, M(0x9b5d4a), 0, -0.12, 0.255);
    add(head, 0.54, 0.14, 0.54, hair, 0, 0.27, 0);
    add(head, 0.54, 0.12, 0.1, hair, 0, 0.18, 0.22);
    if (!fem) add(head, 0.54, 0.34, 0.08, hair, 0, 0.08, -0.23);
    else { add(head, 0.56, 0.78, 0.1, hair, 0, -0.14, -0.25); add(head, 0.06, 0.42, 0.22, hair, -0.28, 0.02, -0.1); add(head, 0.06, 0.42, 0.22, hair, 0.28, 0.02, -0.1); }

    switch (c.accessory) {
      case 'glasses':
        for (const x of [-0.12, 0.12]) { add(head, 0.2, 0.15, 0.03, dark, x, 0.05, 0.27); add(head, 0.14, 0.09, 0.035, M(0x93c5fd), x, 0.05, 0.27); }
        add(head, 0.06, 0.03, 0.03, dark, 0, 0.07, 0.27); break;
      case 'headset':
        add(head, 0.6, 0.05, 0.12, purple, 0, 0.36, 0); add(head, 0.08, 0.22, 0.2, purple, -0.3, 0.02, 0);
        add(head, 0.08, 0.22, 0.2, purple, 0.3, 0.02, 0); add(head, 0.04, 0.04, 0.24, dark, -0.3, -0.12, 0.14); break;
      case 'cap':
        add(head, 0.58, 0.17, 0.58, purple, 0, 0.34, 0); add(head, 0.5, 0.04, 0.3, purple, 0, 0.27, 0.4); break;
      case 'tie':
        add(g, 0.1, 0.4, 0.02, M(0x4c1d95), 0, 1.07, 0.17); add(g, 0.13, 0.09, 0.03, M(0x4c1d95), 0, 1.31, 0.17); break;
    }
    const carry = add(g, 0.5, 0.42, 0.5, M(0xffffff), 0, 0.95, 0.62);
    carry.visible = false;
    return { group: g, legL, legR, armL, armR, carry };
  }

  function animateAvatar(a, x, z, dt) {
    const inst = a.last ? Math.hypot(x - a.last.x, z - a.last.z) / Math.max(dt, 0.001) : 0;
    a.last = { x, z };
    a.speed += (Math.min(inst, 8) - a.speed) * Math.min(1, dt * 12);
    const k = Math.min(1, a.speed / S.PLAYER_SPEED);
    a.phase += a.speed * dt * 2.2;
    const sw = Math.sin(a.phase) * 0.75 * k;
    a.legL.rotation.x = sw; a.legR.rotation.x = -sw;
    if (a.carry.visible) { a.armL.rotation.x = a.armR.rotation.x = -1.25; }
    else { a.armL.rotation.x = -sw * 0.9; a.armR.rotation.x = sw * 0.9; }
    a.group.position.y += Math.abs(Math.sin(a.phase)) * 0.05 * k;
  }

  const meta = new Map();
  const avatars = new Map();
  let mySid = null, myRole = null, myName = '';

  function ensureAvatar(sid) {
    let a = avatars.get(sid);
    if (a) return a;
    const m = meta.get(sid) || { name: 'Colega', role: 'reception', custom: S.DEFAULT_CUSTOM };
    a = buildAvatar(m.custom);
    a.key = JSON.stringify(m.custom);
    a.speed = 0; a.phase = 0; a.last = null; a.emoteUntil = 0;
    a.label = makeLabel('player' + (sid === mySid ? ' me' : ''), m.name);
    scene.add(a.group);
    avatars.set(sid, a);
    return a;
  }
  function rebuildAvatar(a, custom) {
    const pos = a.group.position.clone(), ry = a.group.rotation.y;
    scene.remove(a.group);
    Object.assign(a, buildAvatar(custom), { key: JSON.stringify(custom) });
    a.group.position.copy(pos); a.group.rotation.y = ry;
    scene.add(a.group);
  }
  function removeAvatar(sid) {
    const a = avatars.get(sid);
    if (!a) return;
    scene.remove(a.group); a.label.el.remove(); avatars.delete(sid);
  }
  function setCarry(a, code) {
    if (!code) { a.carry.visible = false; return; }
    a.carry.visible = true; a.carry.material.color.setHex(CODE_COLOR[code]);
  }
  function lerpAngle(a, b, t) {
    let d = (b - a) % (Math.PI * 2);
    if (d > Math.PI) d -= Math.PI * 2;
    if (d < -Math.PI) d += Math.PI * 2;
    return a + d * t;
  }

  // ---------- clientes NPC na fila do balcão (apenas visuais; vêm do `world`) ----------
  const npcs = new Map();
  function syncNpcs() {
    if (!world) return;
    const ids = new Set(world.cl.map((c) => c.id));
    for (const [id, n] of npcs) if (!ids.has(id)) { scene.remove(n.group); n.label.el.remove(); npcs.delete(id); }
    world.cl.forEach((c, i) => {
      let n = npcs.get(c.id);
      if (!n) {
        n = buildAvatar(S.sanitizeCustom(c.look));
        n.label = makeLabel('station', c.name);
        n.phase = Math.random() * 6;
        scene.add(n.group); npcs.set(c.id, n);
      }
      n.label.t.textContent = (c.serving ? '💬 ' : '') + c.name;
      n.group.position.set(-12.3 + 0.9 * i, 0, -9.3);          // fila ao lado do balcão
      n.group.rotation.y = -Math.PI / 2;                       // virados para o balcão
    });
  }

  // ---------- pré-visualização do personagem ----------
  const preview = { r: null, scene: null, cam: null, av: null, active: false };
  function initPreview() {
    if (preview.r) return;
    const c = document.getElementById('preview-canvas');
    preview.r = new THREE.WebGLRenderer({ canvas: c, antialias: true, alpha: true });
    preview.r.setSize(c.width, c.height, false);
    preview.scene = new THREE.Scene();
    preview.scene.add(new THREE.AmbientLight(0xffffff, 0.85));
    const l = new THREE.DirectionalLight(0xffffff, 0.6); l.position.set(3, 6, 5); preview.scene.add(l);
    preview.cam = new THREE.PerspectiveCamera(28, c.width / c.height, 0.1, 50);
    preview.cam.position.set(0, 1.25, 6.8); preview.cam.lookAt(0, 1.0, 0);
  }
  function setPreview(custom) {
    initPreview();
    let ry = 0.5;
    if (preview.av) { ry = preview.av.group.rotation.y; preview.scene.remove(preview.av.group); }
    preview.av = buildAvatar(S.sanitizeCustom(custom));
    preview.av.group.rotation.y = ry;
    preview.scene.add(preview.av.group);
  }

  // ==========================================================================
  // 4) REDE
  // ==========================================================================
  const socket = io();
  let joined = false;
  let world = null;

  const me = { x: 0, y: 0, z: 0, ry: 0, carry: 0 };
  const prevPos = { x: 0, z: 0 };
  const offset = { x: 0, z: 0 };
  let seq = 0, pending = [], outbox = [];
  const snapBuf = [];

  socket.on('roster', (r) => {
    meta.clear();
    for (const p of r.players) meta.set(p.sid, { name: p.name, role: p.role, custom: p.custom });
    UI.updateRoster(r, mySid);
    for (const sid of [...avatars.keys()]) if (!meta.has(sid)) removeAvatar(sid);
    for (const [sid, a] of avatars) {
      const m = meta.get(sid);
      a.label.t.textContent = m.name;
      if (JSON.stringify(m.custom) !== a.key) rebuildAvatar(a, m.custom);
    }
    if (joined && meta.has(mySid)) {
      const m = meta.get(mySid);
      UI.setMyCustom(m.custom);
      if (m.role !== myRole) {
        const first = myRole === null;
        myRole = m.role; UI.setMe(myName, myRole);
        if (world) UI.setHud(world, myRole);
        if (!first) UI.toast(`Foste reatribuído(a) para ${S.ROLE_LABEL[myRole]}.`, 'info');
      }
    }
  });

  socket.on('snap', (msg) => {
    const m = new Map();
    for (const a of msg.p) m.set(a[0], { x: a[1], y: a[2], z: a[3], ry: a[4], carry: a[5], ack: a[6] });
    snapBuf.push({ at: performance.now(), m });
    while (snapBuf.length > 40) snapBuf.shift();
    const mine = m.get(mySid);
    if (joined && mine) reconcile(mine);
  });

  socket.on('world', (w) => { world = w; UI.setHud(w, myRole); applyWorld(); syncNpcs(); });
  socket.on('chat', (m) => UI.addChat(m));

  // ---- eventos DIRECIONADOS (o servidor só os envia aos sockets certos) ----
  socket.on('client_arrived', (d) => UI.showClientBanner(d.customer, d.waiting));    // só Recepção
  socket.on('notify_task', (d) => UI.showTaskBanner(d));                            // só o departamento escolhido
  socket.on('triage_feedback', (d) => UI.toast(d.text, 'info'));                    // só Recepção
  socket.on('delivered', (d) => UI.toast(`${d.customer}: “${d.text}”  ${'★'.repeat(d.stars)}${'☆'.repeat(5 - d.stars)}`, 'info'));
  socket.on('info', (d) => UI.toast(d.msg, 'info'));

  socket.on('open_station', (v) => UI.openStation(v));
  socket.on('close_station', () => UI.closeStation(false));
  socket.on('denied', (d) => UI.toast(d.msg));
  socket.on('emote', ({ sid, e }) => {
    const a = avatars.get(sid);
    if (!a) return;
    a.label.e.textContent = e; a.emoteUntil = performance.now() + 2500;
  });
  socket.on('disconnect', () => { UI.toast('Ligação perdida. A recarregar…'); setTimeout(() => location.reload(), 3000); });

  UI.on.join = (name, custom) => {
    socket.emit('join', { name, custom }, (res) => {
      if (!res.ok) return UI.joinError(res.error);
      mySid = res.you.sid; myRole = res.you.role; myName = res.you.name;
      Object.assign(me, { x: res.you.x, y: res.you.y, z: res.you.z, ry: 0, carry: 0 });
      prevPos.x = me.x; prevPos.z = me.z;
      joined = true;
      UI.hideJoin(); UI.setMe(myName, myRole); UI.setMyCustom(res.you.custom);
      UI.toast(`Foste atribuído(a) a ${S.ROLE_LABEL[myRole]}.`, 'info');
      world = res.world; UI.setHud(world, myRole); applyWorld(); syncNpcs();
    });
  };
  UI.on.chat = (t) => socket.emit('chat', t);
  UI.on.emote = (e) => socket.emit('emote', e);
  UI.on.interact = () => { if (!joined) return; if (UI.openStationId()) UI.closeStation(true); else socket.emit('interact'); };
  UI.on.action = (ev, payload) => socket.emit(ev, payload);
  UI.on.uiClose = () => socket.emit('ui_close');
  UI.on.customize = (c) => socket.emit('customize', c);
  UI.on.leave = () => { socket.disconnect(); location.reload(); };
  UI.on.voice = (on) => UI.toast(on ? 'Voz: protótipo (WebRTC na V2).' : 'Voz desligada.', 'info');
  UI.on.openPreview = (c) => { setPreview(c); preview.active = true; };
  UI.on.previewChange = (c) => setPreview(c);
  UI.on.closePreview = () => { preview.active = false; };

  // ---------- navegação: farol roxo ----------
  const beacon = new THREE.Group();
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.8, 7, 20, 1, true),
    new THREE.MeshBasicMaterial({ color: PURPLE, transparent: true, opacity: 0.3, side: THREE.DoubleSide, depthWrite: false }));
  beam.position.y = 3.5;
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.2, 28), new THREE.MeshBasicMaterial({ color: PURPLE, transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
  ring.rotation.x = -Math.PI / 2; ring.position.y = 0.05;
  beacon.add(beam, ring); beacon.visible = false; scene.add(beacon);
  let beaconUntil = 0;
  UI.on.goto = (id) => {
    const z = S.ZONES.find((q) => q.id === id);
    if (!z) return;
    beacon.position.set(z.x, 0, z.z); beacon.visible = true; beaconUntil = performance.now() + 5000;
  };

  // ==========================================================================
  // 5) INPUT
  // ==========================================================================
  const keys = new Set();
  const characterOpen = () => !document.getElementById('character-modal').hidden;
  window.addEventListener('keydown', (e) => {
    if (!joined || UI.isTyping() || characterOpen()) return;
    const k = e.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    if (k === 'e' || k === ' ') { if (!e.repeat) UI.on.interact(); return; }
    if (/^[1-5]$/.test(k)) { if (!e.repeat) UI.on.emote(UI.EMOTES[+k - 1]); return; }
    keys.add(k);
  });
  window.addEventListener('keyup', (e) => keys.delete(e.key.toLowerCase()));
  window.addEventListener('blur', () => keys.clear());

  /** Ecrã -> mundo (câmara a yaw 45°). */
  function readInput() {
    if (UI.isTyping() || characterOpen()) return { dx: 0, dz: 0 };
    const up = (keys.has('w') || keys.has('arrowup') ? 1 : 0) - (keys.has('s') || keys.has('arrowdown') ? 1 : 0);
    const right = (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0);
    return { dx: (right - up) / SQ2, dz: (-right - up) / SQ2 };
  }

  // ==========================================================================
  // 6) PREDIÇÃO + RECONCILIAÇÃO
  // ==========================================================================
  function fixedStep() {
    prevPos.x = me.x; prevPos.z = me.z;
    const inp = readInput();
    inp.seq = ++seq;
    S.stepPlayer(me, inp, S.DT);
    pending.push(inp); outbox.push(inp);
    if (pending.length > 180) pending.shift();
    if (outbox.length > 60) outbox.shift();
  }
  setInterval(() => {
    if (!joined || !outbox.length) return;
    socket.emit('inputs', outbox);
    outbox = [];
  }, 33);

  function reconcile(srv) {
    const bx = me.x, bz = me.z;
    me.x = srv.x; me.y = srv.y; me.z = srv.z;
    while (pending.length && pending[0].seq <= srv.ack) pending.shift();
    for (const inp of pending) S.stepPlayer(me, inp, S.DT);
    const ex = bx - me.x, ez = bz - me.z;
    if (Math.hypot(ex, ez) > 3) { offset.x = 0; offset.z = 0; } else { offset.x += ex; offset.z += ez; }
    me.carry = srv.carry;
  }

  // ==========================================================================
  // 7) ACTUALIZAÇÃO VISUAL
  // ==========================================================================
  let acc = 0;

  function updateLocal(dt) {
    const a = ensureAvatar(mySid);
    const alpha = acc / S.DT;
    const k = Math.exp(-dt * 12);
    offset.x *= k; offset.z *= k;
    const x = prevPos.x + (me.x - prevPos.x) * alpha + offset.x;
    const z = prevPos.z + (me.z - prevPos.z) * alpha + offset.z;
    a.group.position.set(x, me.y, z);
    a.group.rotation.y = lerpAngle(a.group.rotation.y, me.ry, 1 - Math.exp(-dt * 18));
    setCarry(a, me.carry);
    animateAvatar(a, x, z, dt);
    a.renderPos = { x, z };
  }

  function updateRemotes(now, dt) {
    if (!snapBuf.length) return;
    const latest = snapBuf[snapBuf.length - 1];
    for (const sid of [...avatars.keys()]) if (sid !== mySid && !latest.m.has(sid)) removeAvatar(sid);

    const rt = now - INTERP_DELAY;
    let a = null, b = null;
    for (let i = snapBuf.length - 1; i >= 0; i--) {
      if (snapBuf[i].at <= rt) { a = snapBuf[i]; b = snapBuf[i + 1] || null; break; }
    }
    if (!a) a = snapBuf[0];
    const t = b ? Math.min(1, Math.max(0, (rt - a.at) / (b.at - a.at))) : 0;

    for (const [sid, cur] of latest.m) {
      if (sid === mySid) continue;
      const av = ensureAvatar(sid);
      const sa = a.m.get(sid), sb = b ? b.m.get(sid) : null;
      let x, y, z, ry;
      if (sa && sb) {
        x = sa.x + (sb.x - sa.x) * t; y = sa.y + (sb.y - sa.y) * t; z = sa.z + (sb.z - sa.z) * t;
        ry = lerpAngle(sa.ry, sb.ry, t);
      } else { const s = sb || sa || cur; x = s.x; y = s.y; z = s.z; ry = s.ry; }
      av.group.position.set(x, y, z);
      av.group.rotation.y = ry;
      setCarry(av, cur.carry);
      animateAvatar(av, x, z, dt);
      av.renderPos = { x, z };
    }
  }

  function applyWorld() {
    if (!world) return;
    for (const [id, v] of views) {
      const d = world.st[id];
      if (!d) continue;
      if (v.s.type === 'table') {
        v.slots.forEach((m, i) => { m.visible = d[i] > 0; if (d[i]) m.material.color.setHex(CODE_COLOR[d[i]]); });
      } else if (v.s.type === 'bench') {
        const m = v.slots[0];
        m.visible = d[1] > 0;                                  // d = [código, fase 0..3]
        if (d[0]) m.material.color.setHex(CODE_COLOR[d[0]]);
        v.label.t.textContent = v.base + (d[1] === 2 ? ' 🔧' : d[1] === 3 ? ' ✔' : '');
      }
    }
  }

  function updateStationVisuals(now) {
    for (const v of views.values()) {
      if (v.s.type === 'bench' && world && world.st[v.s.id] && world.st[v.s.id][1] === 2) v.slots[0].rotation.y = now / 400;
    }
    for (const n of npcs.values()) n.group.position.y = 0.03 * Math.sin(now / 400 + n.phase);   // respiração idle
    if (beacon.visible) {
      if (now > beaconUntil) beacon.visible = false;
      else { const p = 0.5 + 0.5 * Math.sin(now / 180); beam.material.opacity = 0.18 + 0.2 * p; ring.scale.setScalar(1 + 0.25 * p); }
    }
  }

  let lastNear = null;
  function updatePrompt() {
    const a = avatars.get(mySid);
    if (!a || !a.renderPos) return;

    const openId = UI.openStationId();
    if (openId) {
      const v = views.get(openId);
      if (v && S.distToRect(a.renderPos.x, a.renderPos.z, v.s) > S.INTERACT_RANGE + 0.4) UI.closeStation(true);
    }

    let best = null, bd = Infinity;
    for (const v of views.values()) {
      const d = S.distToRect(a.renderPos.x, a.renderPos.z, v.s);
      if (d <= S.INTERACT_RANGE && d < bd) { bd = d; best = v; }
    }
    if (best !== lastNear) {
      if (lastNear) lastNear.top.material.emissive.setHex(0x000000);
      if (best) best.top.material.emissive.setHex(0x4c1d95);
      lastNear = best;
    }
    if (!best || UI.modalOpen()) return UI.setPrompt(null);

    const s = best.s;
    if (s.role && s.role !== myRole) return UI.setPrompt(`🔒 ${s.label}: apenas ${S.ROLE_LABEL[s.role]}`, true);
    const carrying = me.carry > 0;
    const d = world && world.st[s.id];
    let verb;
    switch (s.type) {
      case 'counter': verb = 'Atender cliente'; break;
      case 'table':
        if (s.kind === 'in') verb = myRole === 'reception' ? 'Mesa de Triagem (só técnicos recolhem)' : 'Pegar máquina encaminhada para ti';
        else verb = carrying ? 'Deixar PC reparado' : (myRole === 'reception' ? 'Pegar PC reparado' : 'Mesa de Saída');
        break;
      case 'bench': verb = carrying ? 'Colocar máquina na bancada' : (d && d[1] > 0 ? 'Abrir bancada' : 'Bancada livre'); break;
      case 'delivery': verb = carrying ? 'Entregar PC ao cliente' : 'Traz um PC reparado'; break;
    }
    UI.setPrompt(`[E] ${verb}`, false);
  }

  function positionLabels(now) {
    for (const v of views.values()) placeLabel(v.label, v.s.x, v.h + 1.7, v.s.z);
    for (const n of npcs.values()) placeLabel(n.label, n.group.position.x, 2.55, n.group.position.z);
    for (const a of avatars.values()) {
      if (a.emoteUntil && now > a.emoteUntil) { a.label.e.textContent = ''; a.emoteUntil = 0; }
      const p = a.group.position;
      placeLabel(a.label, p.x, 2.55, p.z);
    }
  }

  // ==========================================================================
  // 8) LOOP PRINCIPAL
  // ==========================================================================
  let last = performance.now();
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min((now - last) / 1000, 0.1);
    last = now;
    if (joined) {
      acc += dt;
      while (acc >= S.DT) { acc -= S.DT; fixedStep(); }
      updateLocal(dt);
      updateRemotes(now, dt);
      updateStationVisuals(now);
      updatePrompt();
    }
    renderer.render(scene, camera);
    positionLabels(now);

    if (preview.active && preview.av) {
      preview.av.group.rotation.y += dt * 0.9;
      const sw = Math.sin(now / 500) * 0.15;
      preview.av.armL.rotation.x = sw; preview.av.armR.rotation.x = -sw;
      preview.r.render(preview.scene, preview.cam);
    }
  }
  requestAnimationFrame(frame);
})();
